package cn.his.controller;

import cn.his.entity.JsonResult;
import cn.his.entity.User;
import cn.his.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;

@RestController
public class LoginController {

    @Autowired
    private UserService userService;
    @RequestMapping("/login")
    public JsonResult<User> login(@RequestParam("username") String uname, @RequestParam("password") String pwd, HttpSession session){
        Integer userType=0;
        User user=userService.login(uname,pwd);
        if (user!=null){
            session.setAttribute("loginUser",user);
            return new JsonResult<>("ok",user);
        }else {
            return new JsonResult<>("err",null);
        }
    }
    @RequestMapping("/clear")
    public void clear(HttpSession session){
        session.invalidate();
    }

    @RequestMapping("/gets")
    public JsonResult<User> get(HttpSession session){
        User user=(User) session.getAttribute("loginUser");
        if (user!=null){
            return  new JsonResult<>("ok",user);
        }
        return  new JsonResult<>("err",null);
    }
}
