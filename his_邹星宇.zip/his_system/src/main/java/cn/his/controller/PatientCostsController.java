package cn.his.controller;

import cn.his.entity.JsonResult;
import cn.his.entity.PatientCosts;
import cn.his.entity.Register;
import cn.his.service.PatientCostsService;
import cn.his.service.RegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * 费用查询控制器
 */
@RestController

public class PatientCostsController {

    @Autowired
    private PatientCostsService patientCostsService;
    @Autowired
    private RegisterService registerService;

    /**
     * 患者消费明细查询
     * @param request
     * @return
     */
    @RequestMapping(value="/get/costlist")
    public JsonResult<Map> getCostList(HttpServletRequest request){
        HashMap map1=new HashMap();
        String caseNumber=request.getParameter("CaseNumber");
        String begin=request.getParameter("begin");
        String end=request.getParameter("end");
        if (begin==""){
            begin=null;
        }
        if (end==""){
            end=null;
        }
        HashMap<String,Object> map=new HashMap();
        //获得挂号id
        Register register=registerService.getRegByCaseNumber(caseNumber);
        Integer id=register.getId();
        map.put("id",id);
        map.put("begin",begin);
        map.put("end",end);
        ArrayList<PatientCosts> patientCosts=patientCostsService.selectByRegistID(map);
        if (patientCosts!=null && patientCosts.size()!=0){
            map1.put("patientCosts",patientCosts);
            map1.put("register",register);
            return new JsonResult<>("ok",map1);
        }else {
            return new JsonResult<>("ondata",null);
        }
    }
}
