package cn.his.entity;

import java.util.Date;

public class RegistWork {
    private Integer id;

    private Integer registerid;

    private Date starttime;

    private Date endtime;

    public RegistWork(Integer registerid, Date starttime, Date endtime) {
        this.registerid = registerid;
        this.starttime = starttime;
        this.endtime = endtime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getRegisterid() {
        return registerid;
    }

    public void setRegisterid(Integer registerid) {
        this.registerid = registerid;
    }

    public Date getStarttime() {
        return starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    public Date getEndtime() {
        return endtime;
    }

    public void setEndtime(Date endtime) {
        this.endtime = endtime;
    }
}