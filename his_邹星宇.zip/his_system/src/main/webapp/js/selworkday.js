var demo1=new Vue({
    el:'#selwork_vue',
    data:{
        user:"",
        is1:false,
        is2:false,
        min:"",
        money: "",
        max:"",
        delNumbers:"",
        againNumbers:"",
        createDate:"",
        registWork:{
            registerid:"",
            starttime:"",
            endtime:""
        },
        registWorks:""
    },
    methods:{
        sel:function () {
            var _self=this;
            _self.is2=false;
            $.getJSON("http://localhost:8088/select/works",
                {
                    "begin":_self.registWork.starttime,
                    "end":_self.registWork.endtime
                },
                function (dt) {
                    if (dt.status=="ok"){
                        _self.is1=true;
                        _self.registWorks=dt.data.registWorks;
                    }
                }
            )
        },
        get:function (registWork) {
            var _self=this;
            $.ajax({
                url: "http://localhost:8088/select/detail",
                type: 'POST',
                data:JSON.stringify(registWork),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        _self.is2=true;
                        _self.min=dt.data.min;
                        _self.max=dt.data.max;
                        _self.money=dt.data.money;
                        _self.delNumbers=dt.data.delNumbers;
                        _self.againNumbers=dt.data.againNumbers;
                        _self.createDate=new Date();
                    }else{
                        alert("err");
                    }
                }
            })
        }
    },
    computed: {

    }
});
$(function () {
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo1.$data.user=dt.data.realname;
            }
        })
})

