var demo1=new Vue({
    el:'#workday_vue',
    data:{
        user:"",
        is:false,
        min:"",
        money: "",
        max:"",
        delNumbers:"",
        againNumbers:"",
        createDate:"",
        registWork:{
            registerid:"",
            starttime:"",
            endtime:""
        }
    },
    methods:{
        sel:function () {
            var _self=this;
            $.getJSON("http://localhost:8088/get/day",
                {   "userID":_self.registWork.registerid,
                        "begin":_self.registWork.starttime,
                        "end":_self.registWork.endtime
                },
                function (dt) {
                    if (dt.status=="ok"){
                        _self.is=true;
                        _self.min=dt.data.min;
                        _self.max=dt.data.max;
                        _self.money=dt.data.money;
                        _self.delNumbers=dt.data.delNumbers;
                        _self.againNumbers=dt.data.againNumbers;
                        _self.createDate=new Date();
                    }
                }
            )
        },
        save:function () {
            var _self=this;
            $.ajax({
                url: "http://localhost:8088/save/day",
                type: 'POST',
                data:JSON.stringify(_self.registWork),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        alert("ok!")
                        window.location.reload();
                    }else{
                        alert("err");
                    }
                }
            })
        }
    },
    computed: {

    }
});
$(function () {
    $.getJSON("http://localhost:8088/get/endtime",
                function (dt) {
                    if (dt.status=="ok"){
                        demo1.$data.registWork.starttime=dt.data.endtime;
                    }
                }
        )
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo1.$data.user=dt.data.realname;
            }
        })
});
