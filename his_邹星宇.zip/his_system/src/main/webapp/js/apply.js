var demo1=new Vue({
    el:'#apply_vue',
    data:{
        user:"",
        is1:false,
        is2:false,
        is3:false,
        CheckNameList:"",
        person:{
            realName:"",
            age:"",
            caseNumber:"",
            constantName:"",
            creationtime:"",
            deptName:"",
            invoiceNum:"",
            settleName:"",
            userName:"",
            id:""
        },
        checkApply:{
            RegistID:"",
            RecordType:""
        },
        item:"",
        result:""
    },
    methods:{
        sel:function () {
            this.is2=false;
            var _self=this;
            $.getJSON("http://localhost:8088/select/listbyname",
                {   "RealName":_self.person.realName
                },
                function (dt) {
                    if (dt.status=="ok"){
                        _self.is1=true;
                        _self.CheckNameList=dt.data;
                    }else{
                        alert("没有数据");
                        _self.is1=false;
                    }}
            )
        },
        swc:function (i) {
            switch (i) {
                case 1:return "暂存";break;
                case 2:return "已开立";break;
                case 3:return "已缴费";break;
                case 4:return "已登记";break;
                case 5:return "已执行";break;
                case 6:return "已退费";break;
                case 0:return "已作废";break;
            }
        },
        get3:function (person) {
            this.person=person;
            this.is2=true;
            this.checkApply.RegistID=this.person.id;
            this.checkApply.RecordType=3;
            var _self=this;
            $.ajax({
                url: "http://localhost:8088/select/items",
                type: 'POST',
                data:JSON.stringify(_self.checkApply),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        for (var i in dt.data){
                            dt.data[i].vstring=_self.swc(dt.data[i].state)
                        }
                        _self.item=dt.data;
                    }else{
                        alert("err");
                    }
                }
            })
        },
        get2:function (person) {
            this.person=person;
            this.is2=true;
            this.checkApply.RegistID=this.person.id;
            this.checkApply.RecordType=2;
            var _self=this;
            $.ajax({
                url: "http://localhost:8088/select/items",
                type: 'POST',
                data:JSON.stringify(_self.checkApply),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        for (var i in dt.data){
                            dt.data[i].vstring=_self.swc(dt.data[i].state)
                        }
                        _self.item=dt.data;
                    }else{
                        alert("err");
                    }
                }
            })
        },
        get1:function (person) {
            this.person=person;
            this.is2=true;
            this.checkApply.RegistID=this.person.id;
            this.checkApply.RecordType=1;
            var _self=this;
            $.ajax({
                url: "http://localhost:8088/select/items",
                type: 'POST',
                data:JSON.stringify(_self.checkApply),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        for (var i in dt.data){
                            dt.data[i].vstring=_self.swc(dt.data[i].state)
                        }
                        _self.item=dt.data;
                    }else{
                        alert("err");
                    }
                }
            })
        },
        doapply:function (i,index) {
            var _self=this;
            if ( _self.item[index].vstring!="已执行"){
                $.getJSON("http://localhost:8088/update/doapply",
                    {   "id":i
                    },
                    function (dt) {
                        if (dt.status=="ok"){
                            _self.item[index].vstring="已执行";
                        }else{
                            alert("没有数据");
                            _self.is1=false;
                        }}
                )
            }else {
                alert("已经执行")
            }
        },
        show:function () {
            this.is3=true;
        },
        res:function (i) {
            var _self=this;
                $.getJSON("http://localhost:8088/update/result",
                    {   "id":i,
                            "result":_self.result
                    },
                    function (dt) {
                        if (dt.status=="ok"){
                            alert("提交成功");
                        }else{
                            alert("提交失败");
                        }}
                )
            _self.is3=false;
        },
    },
    computed: {

    }
});
$(function () {
     var _self=this;
    $.getJSON("http://localhost:8088/get/list",
        function (dt) {
            if (dt.status=="ok"){
                demo1.$data.is1=true;
                demo1.$data.CheckNameList=dt.data;
            }
        }
    )
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo1.$data.user=dt.data.realname;
            }
        })
});
