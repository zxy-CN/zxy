var demo1=new Vue({
    el:'#return_vue',
    data:{
        user:"",
        is:false,
        register:{
            casenumber:"",
            realname:"",
            idnumber:"",
            homeaddress:"",
            registtime:"",
            noon:"",
            deptid:"",
            visitstate:"",
            deptname:""
        },
        visitsString:""
    },
    methods:{
        sel:function(){
            var _self=this;
            $.getJSON("http://localhost:8088/get/reg",
                {"CaseNumber":_self.register.casenumber},
                function(dt) {
                    if(dt.status=="ok"){
                        _self.register=dt.data;
                        _self.is="true";
                        switch (_self.register.visitstate) {
                            case 1:_self.visitsString="已挂号";break;
                            case 2:_self.visitsString="医生接诊";break;
                            case 3:_self.visitsString="看诊结束";break;
                            case 4:_self.visitsString="已退号";break;
                        }
                    }else {
                        _self.is="false";
                        alert("没有此病历!");
                        _self.register.realname="";
                        _self.register.idnumber="";
                        _self.register.homeaddress="";
                        _self.register.casenumber="";
                        _self.register.registtime="";
                        _self.register.noon="";
                        _self.register.deptid="";
                        _self.register.visitstate="";
                        _self.visitsString="";
                        _self.register.deptname="";
                    }
                })
        },
        ret:function () {
            var _self=this;
            if (_self.visitsString!="已退号") {
                if (confirm("确认退号？")) {
                    $.getJSON("http://localhost:8088/return/reg",
                        {"CaseNumber":_self.register.casenumber},
                        function(dt) {
                            if(dt.status=="ok"){
                                _self.$set(_self.register, 'visitstate', '4');
                                _self.visitsString="已退号";
                            }else {
                                alert("退号失败!");
                            }
                        })
                }
            }else {
                alert("已经退号")
            }

        }
    },
    computed: {

    }
});
$(function () {
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo1.$data.user=dt.data.realname;
            }
        })
})