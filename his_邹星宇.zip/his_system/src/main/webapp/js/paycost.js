var demo = new Vue({
    el: '#paycost_vue',
    data: {
        user:"",
        casenumber: "",
        realname: "",
        idnumber: "",
        homeaddress: "",
        vChargeCapplies: "",
        vChargeHerbals: "",
        vChargePrescriptions: ""
    },
    methods: {
        sel: function () {
            var _self = this;
            $.getJSON("http://localhost:8088/get/cost",
                {"CaseNumber": _self.casenumber},
                function (dt) {
                    if (dt.status == "ok") {
                        for (var i in dt.data.vChargeCapplies){
                            dt.data.vChargeCapplies[i].vstring=_self.swc(dt.data.vChargeCapplies[i].state)
                        }
                        for (var i in dt.data.vChargeHerbals){
                            dt.data.vChargeHerbals[i].vstring=_self.swc(dt.data.vChargeHerbals[i].state)
                        }
                        for (var i in dt.data.vChargePrescriptions){
                            dt.data.vChargePrescriptions[i].vstring=_self.swc(dt.data.vChargePrescriptions[i].state)
                        }
                        _self.$set(_self,"vChargeCapplies",dt.data.vChargeCapplies);
                        _self.$set(_self,"vChargeHerbals",dt.data.vChargeHerbals);
                        _self.$set(_self,"vChargePrescriptions",dt.data.vChargePrescriptions);
                        _self.$set(_self,"realname",dt.data.register.realname);
                        _self.$set(_self,"idnumber",dt.data.register.idnumber);
                        _self.$set(_self,"homeaddress",dt.data.register.homeaddress);
                        _self.$forceUpdate();
                        console.log(_self);
                        // _self.vChargeCapplies = dt.data.vChargeCapplies;
                        // _self.vChargeHerbals = dt.data.vChargeHerbals;
                        // _self.vChargePrescriptions = dt.data.vChargePrescriptions;
                        // _self.realname = dt.data.register.realname;
                        // _self.idnumber = dt.data.register.idnumber;
                        // _self.homeaddress = dt.data.register.homeaddress;
                    }else if(dt.status == "nocost"){
                        alert("没有消费!");
                        _self.$set(_self,"vChargeCapplies",null);
                        _self.$set(_self,"vChargeHerbals",null);
                        _self.$set(_self,"vChargePrescriptions",null);
                        _self.$set(_self,"realname",dt.data.register.realname);
                        _self.$set(_self,"idnumber",dt.data.register.idnumber);
                        _self.$set(_self,"homeaddress",dt.data.register.homeaddress);
                        _self.$forceUpdate();
                        console.log(_self);
                    }else {
                        alert("没有此病人!");
                        _self.$set(_self,"vChargeCapplies",null);
                        _self.$set(_self,"vChargeHerbals",null);
                        _self.$set(_self,"vChargePrescriptions",null);
                        _self.$set(_self,"realname",null);
                        _self.$set(_self,"idnumber",null);
                        _self.$set(_self,"homeaddress",null);
                        _self.$forceUpdate();
                        console.log(_self);
                    }
                });
            this.$forceUpdate();
        },
        //1-暂存
        // 2-已开立
        // 3-已交费
        // 4-已取药
        // 5-已退药
        // 6-已退费
        // 0-已作废
        swc:function (i) {
            switch (i) {
                case 1:return "暂存";break;
                case 2:return "已开立";break;
                case 3:return "已缴费";break;
                case 4:return "已取药";break;
                case 5:return "已退药";break;
                case 6:return "已退费";break;
                case 0:return "已作废";break;
            }
        },
        pay:function (cid,pid,hid,num,i) {
            var _self=this;
            if (_self.vChargeCapplies[i].vstring!="已缴费" || _self.vChargePrescriptions[i].vstring!="已缴费" || _self.vChargeHerbals[i].vstring!="已缴费") {
                if (confirm("确认缴费？")) {
                    $.getJSON("http://localhost:8088/update/cost",
                        {
                            "CaseNumber":num,
                            "c_id":cid,
                            "h_id":hid,
                            "p_id":pid,
                            "registerId":1
                        },
                        function(dt) {
                            if(dt.status=="ok"){
                                if (cid!=null){
                                    _self.vChargeCapplies[i].vstring="已缴费";
                                } else if(pid!=null){
                                    _self.vChargePrescriptions[i].vstring="已缴费";
                                }else if(hid!=null){
                                    _self.vChargeHerbals[i].vstring="已缴费";
                                }
                            }else {
                                alert("缴费失败!");
                            }
                        })
                }
            }else {
                alert("已经缴费！");
            }
        },
        retcost:function(cid,pid,hid,num,i) {
            var _self=this;
            if (_self.vChargeCapplies[i].vstring!="已退费" || _self.vChargePrescriptions[i].vstring!="已退费" || _self.vChargeHerbals[i].vstring!="已退费") {
                if (confirm("确认退费？")) {
                    $.getJSON("http://localhost:8088/return/cost",
                        {
                            "CaseNumber":num,
                            "c_id":cid,
                            "h_id":hid,
                            "p_id":pid,
                            "registerId":1
                        },
                        function(dt) {
                            if(dt.status=="ok"){
                                if (cid!=null){
                                    _self.vChargeCapplies[i].vstring="已退费";
                                } else if(pid!=null){
                                    _self.vChargePrescriptions[i].vstring="已退费";
                                }else if(hid!=null){
                                    _self.vChargeHerbals[i].vstring="已退费";
                                }
                            }else {
                                alert("退费失败!");
                            }
                        })
                }
            }else {
                alert("已经退费！")
            }
        }
    },
    computed: {}
});
$(function () {
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo.$data.user=dt.data.realname;
            }
        })
})

