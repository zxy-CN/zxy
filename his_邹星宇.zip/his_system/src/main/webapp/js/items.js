var demo1=new Vue({
    el:'#items_vue',
    data:{
        item:"",
        navigatepageNums:"",
        itemName: "",
        user:""
    },
    methods:{
        sel:function () {
            var _self=this;
            $.getJSON("http://localhost:8088/get/page",
                {   "pageNum":1,
                        "itemName":_self.itemName
                },
                function (dt) {
                    if (dt.status=="ok"){
                        _self.item=dt.data.list;
                        _self.navigatepageNums=dt.data.navigatepageNums;
                    }else{
                        alert("没有数据");
                    }}
            )
        },
        page:function (n) {
            var _self=this;
            $.getJSON("http://localhost:8088/get/page",
                {   "pageNum":n,
                    "itemName":_self.itemName
                },
                function (dt) {
                    if (dt.status=="ok"){
                        _self.item=dt.data.list;
                        _self.navigatepageNums=dt.data.navigatepageNums;
                    }else{
                        alert("没有数据");
                    }}
            )
        },
        del:function (item) {
            var _self=this;
            $.ajax({
                url: "http://localhost:8088/del/apply",
                type: 'POST',
                data:JSON.stringify(item),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        alert("ok!")
                        window.location.reload();
                    }else{
                        alert("err");
                    }
                }
            })
        },
    },
    computed: {

    }
});
$(function () {
     var _self=this;
    $.getJSON("http://localhost:8088/get/page",
        {"pageNum":1,
            "itemName":""},
        function (dt) {
            if (dt.status=="ok"){
                demo1.$data.item=dt.data.list;
                demo1.$data.navigatepageNums=dt.data.navigatepageNums;
            }
        }
    )
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo1.$data.user=dt.data.realname;
            }
        })
});
