var demo = new Vue({
    el: '#login_vue',
    data: {
        uname:"",
        pwd:""
    },
    methods: {
        login:function () {
            var _self=this;
            $.getJSON("http://localhost:8088/login",
                {"username":_self.uname,
                     "password":_self.pwd},
                function (dt) {
                    if (dt.status=="ok"){
                        if (dt.data.usertype==2) {
                            window.location.replace("index2.html");
                        }else if(dt.data.usertype==4){
                            window.location.replace("index4.html");
                    }
                    }else {
                        alert("登录失败");
                    }
                })
        }
    },
    computed: {}
});
$(function () {
    $.getJSON("http://localhost:8088/clear")
})

