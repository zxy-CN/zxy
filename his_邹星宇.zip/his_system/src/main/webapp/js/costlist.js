var demo = new Vue({
    el: '#paycost_vue',
    data: {
        user:"",
        casenumber: "",
        realname: "",
        idnumber: "",
        homeaddress: "",
        begin: "",
        end: "",
        patientCosts: "",
        register:"",
    },
    methods: {
        sel: function () {
            var _self = this;
            $.getJSON("http://localhost:8088/get/costlist",
                {
                    "CaseNumber": _self.casenumber,
                    "begin":_self.begin,
                    "end":_self.end
                },
                function (dt) {
                    if (dt.status == "ok") {
                        for (var i in dt.data.patientCosts) {
                            if (dt.data.patientCosts[i].backid!=null) {
                                dt.data.patientCosts[i].back="已经退费";
                            }
                        }
                        _self.patientCosts=dt.data.patientCosts;
                        _self.register=dt.data.register;
                        _self.realname=_self.register.realname;
                        _self.idnumber=_self.register.idnumber;
                        _self.homeaddress=_self.register.homeaddress;
                    }else {
                        alert("没有记录!");
                        _self.$set(_self,"realname",null);
                        _self.$set(_self,"idnumber",null);
                        _self.$set(_self,"homeaddress",null);
                        _self.$set(_self,"begin",null);
                        _self.$set(_self,"end",null);
                        _self.$set(_self,"costlist",null);
                        _self.$forceUpdate();
                    }
                });
            this.$forceUpdate();
        },
    },
    computed: {}
});
$(function () {
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo.$data.user=dt.data.realname;
            }
        })
})

