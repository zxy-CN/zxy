var demo=new Vue({
	el:'#register_form',
	data:{
		regAndInv: {
			register:{
				casenumber:"",
				realname:"",
				gender:"",
				idnumber:"",
				birthdate:"",
				age:"",
				agetype:"天",
				homeaddress:"",
				visitdate:"",
				noon:"",
				deptid:"",
				userid:"",
				registleid:"",
				settleid:"",
				isbook:"是",
				registerid:1,
				visitstate:""

			},
			invoice: {
				invoicenum:"",
				money:"",
				userid:"1",
				feetype:""
			},

		},
		user:""
	},
	methods:{
		login(){
			var _self=this;
			$.ajax({
				url: "http://localhost:8088/add/reg",
				type: 'POST',
				data:JSON.stringify(_self.regAndInv),
				contentType:"application/json;charset=utf-8",
				success: function(dt){
					if(dt.status=="ok"){
						alert("ok!")
						window.location.reload();
					}else{
						alert("err");
					}
				}
			})
		}
	},
	computed: {

	}
})
$(function(){
	var stype,sex,mtc,dept,levle,doc,invoiceNumber;
	$.getJSON("http://localhost:8088/select/reg",function(d){
			var dt=d.data;
			//结算类别
			stype=dt.stype;
			//性别
			sex=dt.sex;
			//支付方式
			mtc=dt.MTC;
			//部门
			dept=dt.dept;
			//挂号级别
			levle=dt.levle;
			//病历号
			caseNumber=dt.caseNumber;
			//发票号
			invoiceNumber=dt.invoice;
			//医生
			doc=dt.doc;
			//填充性别
			$.each(sex, function(i) {
				$("#gender").append("<option value='"+sex[i].id+"'>"+sex[i].constantname+"</option>");
			});
			//填充挂号级别
			$.each(levle, function(i) {
				$("#registLeID").append("<option value='"+levle[i].id+"'>"+levle[i].registname+"</option>");
			});
			//填充结算类别
			$.each(stype, function(i) {
				$("#settleID").append("<option value='"+stype[i].id+"'>"+stype[i].settlename+"</option>");
			});
			//填充看诊科室
			$.each(dept, function(i) {
				$("#deptID").append("<option value='" + dept[i].id + "'>" + dept[i].deptname + "</option>");
			});
			$.each(mtc, function(i) {
				$("#feeType").append("<option value='"+mtc[i].id+"'>"+mtc[i].constantname+"</option>");
			});
			//填充病历
			demo.$data.regAndInv.register.casenumber=caseNumber;
			demo.$data.regAndInv.invoice.invoicenum=invoiceNumber;
		});
		//下拉列表值改变事件
	var lid,did;
	//当科室被选择时，取部门id
	$("#deptID").change(function(){
		$("#userID").html("<option value='0'>--请选择--</option>");
		did=$(this).val();//取选中值
	});
	//当挂号级别被选择时，取挂号级别id
	$("#registLeID").change(function(){
		lid=$(this).val();//取选中值
		$("#userID").html("<option value='0'>--请选择--</option>");
		$.each(doc, function(i) {
			if(doc[i].deptid==did && doc[i].registleid==lid){
				$("#userID").append("<option value='"+doc[i].id+"'>"+doc[i].realname+"</option>");
			}
		});
	});
	$.getJSON("http://localhost:8088/gets",
		function (dt) {
			if (dt.status=="ok") {
				demo.$data.user=dt.data.realname;
			}
		})

});

