var demo1=new Vue({
    el:'#invre_vue',
    data:{
        user:"",
        is:false,
        register:"",
        invoice:"",
        casenumber: "",
        realname: "",
        idnumber: "",
        homeaddress: "",
        state:""
    },
    methods:{
        sel:function(){
            var _self=this;
            $.getJSON("http://localhost:8088/get/inv",
                {"CaseNumber":_self.casenumber},
                function(dt) {
                    if(dt.status=="ok"){
                        _self.register=dt.data.register;
                        _self.invoice=dt.data.invoice;
                        _self.realname=dt.data.register.realname;
                        _self.idnumber=dt.data.register.idnumber;
                        _self.homeaddress=dt.data.register.homeaddress;
                        _self.is="true";
                        switch (_self.invoice.state) {
                            case 1:_self.state="正常";break;
                            case 2:_self.state="作废";break;
                            case 3:_self.state="未打印";break;
                            case 4:_self.state="已打印";break;
                            case 5:_self.state="已重打";break;
                            case 6:_self.state="已补打";break;
                        }
                    }else {
                        _self.is="false";
                        alert("没有此发票!");
                        _self.realname="";
                        _self.idnumber="";
                        _self.homeaddress="";
                    }
                })
        },
        re:function (id) {
            var _self=this;
            if (_self.state!="已重打") {
                if (confirm("确认重打？")) {
                    $.getJSON("http://localhost:8088/re/print",
                        {"registid":id},
                        function(dt) {
                            if(dt.status=="ok"){
                                _self.state="已重打";
                            }else {
                                alert("重打失败!");
                            }
                        })
                }
            }else {
                alert("已经重打")
            }
        },
        ag:function (id) {
            var _self=this;
            if (_self.state!="已补打") {
                if (confirm("确认补打？")) {
                    $.getJSON("http://localhost:8088/ag/print",
                        {"registid":id},
                        function(dt) {
                            if(dt.status=="ok"){
                                _self.state="已补打";
                            }else {
                                alert("补打失败!");
                            }
                        })
                }
            }else {
                alert("已经补打")
            }
        }
    },
    computed: {

    }
});
$(function () {
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo1.$data.user=dt.data.realname;
            }
        })
})
