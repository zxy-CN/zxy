/*
Navicat MySQL Data Transfer

Source Server         : zxy
Source Server Version : 50562
Source Host           : localhost:3306
Source Database       : student_job

Target Server Type    : MYSQL
Target Server Version : 50562
File Encoding         : 65001

Date: 2020-04-02 17:30:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for company
-- ----------------------------
DROP TABLE IF EXISTS `company`;
CREATE TABLE `company` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `uid` int(9) NOT NULL,
  `comName` varchar(64) NOT NULL,
  `comSize` varchar(64) NOT NULL,
  `comAddress` varchar(64) NOT NULL,
  `comLevel` varchar(64) NOT NULL,
  `comDetail` varchar(512) NOT NULL,
  `comType` varchar(64) NOT NULL,
  `comPass` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of company
-- ----------------------------
INSERT INTO `company` VALUES ('1', '2', '百度', '1000人以上', '北京朝阳区', '上市公司', '百度（纳斯达克：BIDU），全球最大的中文搜索引擎及最大的中文网站，全球领先的人工智能公司。百度愿景是：成为最懂用户，并能帮助人们成长的全球顶级高科技公司。', '互联网', '1');
INSERT INTO `company` VALUES ('2', '4', '腾讯', '1000人以上', '深圳', '上市公司', '深圳市腾讯计算机系统有限公司成立于1998年11月 [1]  ，由马化腾、张志东、许晨晔、陈一丹、曾李青五位创始人共同创立。 [1]  是中国最大的互联网综合服务提供商之一，也是中国服务用户最多的互联网企业之一。', '互联网/社交', '1');
INSERT INTO `company` VALUES ('3', '6', '网易', '2000人以上', '杭州', '上市公司', '网易公司（NASDAQ: NTES）是中国的互联网公司，利用互联网技术，加强人与人之间信息的交流和共享，实现“网聚人的力量”。创始人兼CEO是丁磊。在开发互联网应用、服务及其它技术方面，网易在推出了包括中文全文检索、全中文大容量免费邮件系统、无限容量免费网络相册、免费电子贺卡站、网上虚拟社区、网上拍卖平台、24小时客户服务中心在内的业内领先产品或服务，还通过自主研发推出了国产网络游戏。', '互联网、游戏、社交', '1');

-- ----------------------------
-- Table structure for edu_experience
-- ----------------------------
DROP TABLE IF EXISTS `edu_experience`;
CREATE TABLE `edu_experience` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `resId` int(9) NOT NULL,
  `begin` datetime NOT NULL,
  `end` datetime NOT NULL,
  `schoolName` varchar(64) NOT NULL,
  `majorName` varchar(64) NOT NULL,
  `degree` varchar(64) NOT NULL,
  `detail` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of edu_experience
-- ----------------------------
INSERT INTO `edu_experience` VALUES ('1', '1', '2016-09-01 00:00:00', '2020-07-01 00:00:00', '清华大学', '网络工程', '硕士', '大学期间主修了计算机网络，java程序开发等课程');
INSERT INTO `edu_experience` VALUES ('2', '2', '2016-07-01 00:00:00', '2020-07-01 00:00:00', '湖北科技学院', '网络工程', '博士', '学习了网络工程相关知识');

-- ----------------------------
-- Table structure for job
-- ----------------------------
DROP TABLE IF EXISTS `job`;
CREATE TABLE `job` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `jobName` varchar(64) NOT NULL,
  `jobSalary` varchar(64) NOT NULL,
  `jobPlace` varchar(64) NOT NULL,
  `jobRequire` varchar(64) NOT NULL,
  `degreeRequire` varchar(64) NOT NULL,
  `jobType` varchar(64) NOT NULL,
  `keyWords` varchar(64) NOT NULL,
  `jobDetail` varchar(512) NOT NULL,
  `createTime` datetime NOT NULL,
  `comID` int(9) NOT NULL,
  `delMark` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of job
-- ----------------------------
INSERT INTO `job` VALUES ('1', 'Java开发工程师', '10k', '深圳', '五险一金', '本科', '全职', 'java，后端开发', '熟悉java语言，在校有一定的开发经验，编码熟练，熟悉多线程，了解编译原因，linux系统', '2019-12-30 16:01:52', '2', '1');
INSERT INTO `job` VALUES ('2', 'php开发工程师', '15k', '深圳', '五险一金', '硕士', '全职', 'php', '熟悉php语言，有一定的变成基础', '2020-02-08 18:52:52', '1', '1');
INSERT INTO `job` VALUES ('3', '游戏测试工程师', '6-8k', '杭州', '五险一金，精美食堂', '本科', '全职', '测试，游戏', '热爱游戏，有一定的探索精神和发现问题的能力', '2020-02-23 15:43:26', '3', '1');
INSERT INTO `job` VALUES ('5', '游戏测试开发工程师', '8-10k', '上海', '五险一金，年终奖，精美餐厅', '硕士', '全职', '测试，游戏，开发', '有一定的编程基础和逻辑思维，会python，喜欢探究问题', '2020-02-23 16:51:55', '3', '1');

-- ----------------------------
-- Table structure for jobfor
-- ----------------------------
DROP TABLE IF EXISTS `jobfor`;
CREATE TABLE `jobfor` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `resId` int(9) NOT NULL,
  `hopeSalary` varchar(64) NOT NULL,
  `hopePlace` varchar(64) NOT NULL,
  `work` varchar(64) NOT NULL,
  `jobType` varchar(64) NOT NULL,
  `workTime` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of jobfor
-- ----------------------------
INSERT INTO `jobfor` VALUES ('1', '1', '8-10k', '武汉', 'php工程师', '实习', '随时');
INSERT INTO `jobfor` VALUES ('2', '3', '10k+', '杭州', '游戏测试', '全职', '随时');
INSERT INTO `jobfor` VALUES ('3', '2', '10k+', '十堰', '产品经理', '全职', '随时');

-- ----------------------------
-- Table structure for project_experience
-- ----------------------------
DROP TABLE IF EXISTS `project_experience`;
CREATE TABLE `project_experience` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `resId` int(9) NOT NULL,
  `begin` datetime NOT NULL,
  `end` datetime NOT NULL,
  `name` varchar(64) NOT NULL,
  `play` varchar(64) NOT NULL,
  `detail` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of project_experience
-- ----------------------------
INSERT INTO `project_experience` VALUES ('2', '1', '2019-11-10 00:00:00', '2019-11-30 00:00:00', 'his医院管理系统', '模块功能设计', '完成医院his系统的挂号模块以及医技管理模块进行设计。参与数据库设计的讨论与创建，完成功能的底层编写以及测试，对前端页面的模板进行二次开发，优化，按需设计。小组合作');
INSERT INTO `project_experience` VALUES ('3', '2', '2020-02-02 00:00:00', '2020-02-12 00:00:00', '123', '456', '123456789');

-- ----------------------------
-- Table structure for resume
-- ----------------------------
DROP TABLE IF EXISTS `resume`;
CREATE TABLE `resume` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `resName` varchar(64) NOT NULL,
  `uid` int(9) NOT NULL,
  `createTime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of resume
-- ----------------------------
INSERT INTO `resume` VALUES ('1', 'java工程师', '3', '2020-01-01 17:03:55');
INSERT INTO `resume` VALUES ('2', '简历', '10', '2020-02-11 14:21:30');
INSERT INTO `resume` VALUES ('3', '7的简历', '7', '2020-02-13 15:25:57');
INSERT INTO `resume` VALUES ('4', '简历', '12', '2020-03-02 16:42:37');

-- ----------------------------
-- Table structure for school_experience
-- ----------------------------
DROP TABLE IF EXISTS `school_experience`;
CREATE TABLE `school_experience` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `resId` int(9) NOT NULL,
  `begin` datetime NOT NULL,
  `end` datetime NOT NULL,
  `name` varchar(64) NOT NULL,
  `detail` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of school_experience
-- ----------------------------
INSERT INTO `school_experience` VALUES ('1', '1', '2017-09-01 00:00:00', '2018-07-01 00:00:00', '动漫社社长', '任期一年的社长，管理社团活动和人员，举办过两次晚会，管理着100人左右');

-- ----------------------------
-- Table structure for self
-- ----------------------------
DROP TABLE IF EXISTS `self`;
CREATE TABLE `self` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `resId` int(9) NOT NULL,
  `detail` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of self
-- ----------------------------
INSERT INTO `self` VALUES ('1', '1', '诚实，为人上进，吃苦耐劳，乐观正直，敢于直面困难与挑战，喜欢接触新事物与新技，善于利用互联网与论坛进行学习以及寻求问题的解决方式。作为应届生，有一定的编码能力与编码规范，有项目经验与团队合作的经验，能过很快的融入团队，有较好的抗压能力与协调能力，能过按时按量的完成任务。');
INSERT INTO `self` VALUES ('2', '2', '人品优良');

-- ----------------------------
-- Table structure for send
-- ----------------------------
DROP TABLE IF EXISTS `send`;
CREATE TABLE `send` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `jobId` int(9) NOT NULL,
  `resId` int(9) NOT NULL,
  `state` varchar(64) NOT NULL,
  `sendTime` datetime NOT NULL,
  `updataTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of send
-- ----------------------------
INSERT INTO `send` VALUES ('7', '1', '1', '感兴趣', '2020-03-02 17:04:59', '2020-03-02 17:07:37');

-- ----------------------------
-- Table structure for skill
-- ----------------------------
DROP TABLE IF EXISTS `skill`;
CREATE TABLE `skill` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `resId` int(9) NOT NULL,
  `detail` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of skill
-- ----------------------------
INSERT INTO `skill` VALUES ('1', '1', 'java，mysql，JavaScript，html，css');
INSERT INTO `skill` VALUES ('2', '2', 'mysql');

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `uid` int(9) NOT NULL,
  `realName` varchar(64) NOT NULL,
  `idCard` varchar(64) NOT NULL,
  `phone` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `sex` varchar(64) NOT NULL,
  `bornDate` datetime NOT NULL,
  `degree` varchar(64) NOT NULL,
  `schoolName` varchar(64) NOT NULL,
  `majorName` varchar(64) NOT NULL,
  `livePlace` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1', '3', '邹星宇', '42032519970825005X', '15377188967', '841294070@qq.com', '男', '1997-08-29 00:00:00', '博士', '清华大学', '网络工程', '湖北咸宁');
INSERT INTO `student` VALUES ('2', '10', '小王', '44444444', '15444468', '6489944', '男', '2020-02-13 00:00:00', '大专', '技术学院', '信息工程', '湖北十堰');
INSERT INTO `student` VALUES ('3', '12', '邹星宇', '123', '123', '123', '男', '1997-08-29 00:00:00', '本科', '湖北科技学院', '网络工程', '湖北十堰');

-- ----------------------------
-- Table structure for teach
-- ----------------------------
DROP TABLE IF EXISTS `teach`;
CREATE TABLE `teach` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `teachName` varchar(64) NOT NULL,
  `teachTime` datetime NOT NULL,
  `place` varchar(64) NOT NULL,
  `comId` int(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of teach
-- ----------------------------
INSERT INTO `teach` VALUES ('2', '湖科网易游戏宣讲会', '2020-04-15 09:30:00', '西区操场', '3');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `uname` varchar(64) NOT NULL,
  `upwd` varchar(64) NOT NULL,
  `utype` varchar(64) NOT NULL,
  `dmark` int(1) NOT NULL,
  `createTime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'root', 'root', '学生', '1', '2019-12-26 18:27:33');
INSERT INTO `user` VALUES ('2', 'baidu', '123', '企业', '1', '2019-12-26 18:28:03');
INSERT INTO `user` VALUES ('3', '小邹', '456', '学生', '1', '2019-12-26 18:28:18');
INSERT INTO `user` VALUES ('4', '腾讯', '123', '企业', '1', '2019-12-27 16:32:12');
INSERT INTO `user` VALUES ('5', '841294070@qq.com', '123456', '学生', '1', '2020-02-07 15:07:51');
INSERT INTO `user` VALUES ('6', 'wangyi', '123', '企业', '1', '2020-02-07 15:18:59');
INSERT INTO `user` VALUES ('7', 'z96527469', '123', '学生', '1', '2020-02-07 15:36:19');
INSERT INTO `user` VALUES ('8', 'Z841294070', 'Z123456z', '学生', '1', '2020-02-07 15:37:43');
INSERT INTO `user` VALUES ('9', 'z841294070', '12011531zZ', '学生', '1', '2020-02-11 14:18:59');
INSERT INTO `user` VALUES ('10', 'z75208', '123', '学生', '1', '2020-02-11 14:21:30');
INSERT INTO `user` VALUES ('11', 'hasee', '123', '企业', '1', '2020-02-22 15:29:23');
INSERT INTO `user` VALUES ('12', 'zxy123456', 'Z123456z', '学生', '1', '2020-03-02 16:42:37');
INSERT INTO `user` VALUES ('13', 'qiye123', 'Q123456q', '企业', '1', '2020-03-02 16:49:47');
