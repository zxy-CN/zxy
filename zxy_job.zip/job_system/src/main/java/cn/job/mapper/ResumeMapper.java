package cn.job.mapper;

import cn.job.entity.Resume;

public interface ResumeMapper {
    /**
     * 创建一份简历
     * @param resume
     * @return
     */
    int insert(Resume resume);

    /**
     * 根据uid搜索简历
     */
    Resume selectByUid(Integer uid);

    int updateId(Resume resume);

    Resume selectById(Integer id);

}