package cn.job.mapper;

import cn.job.entity.Company;
import cn.job.entity.Job;
import com.github.pagehelper.PageInfo;

import java.util.ArrayList;

public interface JobMapper {
    /**
     * 根据关键字搜索职位（模糊查询）
     * @param keys
     * @return
     */
    ArrayList<Job> selectByKeys(String keys);

//    /**
//     * 根据关键字模糊查询职位
//     * @param name
//     * @return
//     */
//    PageInfo<Company> getComsByname(int pageNum, int pageSize, String name);

    /**
     * 根据职位id查找职位
     * @param id
     * @return
     */
    Job selectById(Integer id);

    /**
     * 根据公司id查找职位
     * @param id
     * @return
     */
    ArrayList<Job> selectBycomId(Integer id);

    /**
     * 添加一个职位
     * @param job
     * @return
     */
    int insert(Job job);

    /**
     * 修改职位信息
     * @param job
     * @return
     */
    int updateById(Job job);

    /**
     * 删除一个职位(非物理)
     * @param id
     * @return
     */
    int delById(Integer id);


}