package cn.job.mapper;

import cn.job.entity.Student;

public interface StudentMapper {
    int deleteByPrimaryKey(Integer id);

    /**
     * 完善学生信息
     * @param student
     * @return
     */
    int insert(Student student);

    int insertSelective(Student record);

    /**
     * 根据用户id查询学生信息
     * @param uid
     * @return
     */
    Student selectByUid(Integer uid);


    /**
     * 根据id查询学生信息
     * @param id
     * @return
     */
    Student selectById(Integer id);

    /**
     * 更改学生信息
     * @param student
     * @return
     */
    int updateByUId(Student student);
}