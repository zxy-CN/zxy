package cn.job.mapper;

import cn.job.entity.SchoolExperience;

import java.util.ArrayList;

public interface SchoolExperienceMapper {

    /**
     * 添加校园经历
     * @param schoolExperience
     * @return
     */
    int insert(SchoolExperience schoolExperience);

    /**
     * 根据简历id查询校园经历
     * @param resId
     * @return
     */
    SchoolExperience selectByResId(Integer resId);

    /**
     * 修改校园经历
     * @param schoolExperience
     * @return
     */
    int updateById(SchoolExperience schoolExperience);

    /**
     * 删除校园经历
     * @param id
     * @return
     */
    int deleteById(Integer id);


}