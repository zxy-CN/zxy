package cn.job.mapper;

import cn.job.entity.Teach;
import com.github.pagehelper.PageInfo;

import java.util.ArrayList;

public interface TeachMapper {
    /**
     * 添加一个宣讲会
     * @param teach
     * @return
     */
    int insert(Teach teach);

    /**
     * 通过id修改此宣讲会的信息
     * @param teach
     * @return
     */
    int updateById(Teach teach);

    /**
     * 通过id删除此宣讲会
     * @param id
     * @return
     */
    int deleteById(Integer id);

    /**
     * 通过企业id查询发布的宣讲会
     * @param comId
     * @return
     */
    ArrayList<Teach> selectByComId(Integer comId);

    /**
     * 通过宣讲会名字查询宣讲会
     * @param keys
     * @return
     */
    ArrayList<Teach> selectByKeys(String keys);

    /**
     * 根据关键字模糊查询职位
     * @param name
     * @return
     */
    PageInfo<Teach> getTeaByname(int pageNum, int pageSize, String name);

}