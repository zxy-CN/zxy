package cn.job.mapper;

import cn.job.entity.Jobfor;

public interface JobforMapper {

    /**
     * 添加一个求职意向
     * @param jobfor
     * @return
     */
    int insert(Jobfor jobfor);

    /**
     * 根据简历id查询工作意向
     * @param resId
     * @return
     */
    Jobfor selectByResId(Integer resId);

    /**
     * 修改求职意向
     * @param jobfor
     * @return
     */
    int updateById(Jobfor jobfor);

    /**
     * 根据工作意向id删除求职意向
     * @param id
     * @return
     */
    int deleteById(Integer id);

}