package cn.job.mapper;

import cn.job.entity.Send;

import java.util.ArrayList;

public interface SendMapper {
    /**
     * 创建一个投递
     * @param send
     * @return
     */
    int insert(Send send);

    /**
     * 修改一个简历的投递状态
     * @param send
     * @return
     */
    int updateById(Send send);

    ArrayList<Send> selectByResId(Send send);

    ArrayList<Send> selectByJobId(Send send);
}