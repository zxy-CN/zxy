package cn.job.mapper;

import cn.job.entity.EduExperience;

import java.util.ArrayList;

public interface EduExperienceMapper {

    /**
     * 添加一个教育经历
     * @param eduExperience
     * @return
     */
    int insert(EduExperience eduExperience);

    /**
     * 根据简历编号查询教育经历
     * @param resId
     * @return
     */
    EduExperience selectByResId(Integer resId);

    /**
     * 修改教育经历
     * @param eduExperience
     * @return
     */
    int updateById(EduExperience eduExperience);

    /**
     * 根据id删除教育经历
     * @param id
     * @return
     */
    int deleteById(Integer id);


}