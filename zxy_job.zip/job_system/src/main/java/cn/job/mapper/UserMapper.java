package cn.job.mapper;

import cn.job.entity.User;

public interface UserMapper {

    /**
     * 登录的方法
     * @param uname,upwd
     * @return
     */
    User selectUser(String uname,String upwd);

    /**
     * 添加学生用户
     * @param user
     * @return
     */
    int insertStu(User user);

    /**
     * 添加企业用户
     * @param user
     * @return
     */
    int insertCom(User user);

    /**
     * 更改密码
     * @param user
     * @return
     */
    int updateById(User user);


}