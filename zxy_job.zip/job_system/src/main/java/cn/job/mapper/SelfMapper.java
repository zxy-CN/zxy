package cn.job.mapper;

import cn.job.entity.Self;

public interface SelfMapper {

    /**
     * 添加自我评价
     * @param self
     * @return
     */
    int insert(Self self);

    /**
     * 根据简历id查询自我评价
     * @param resId
     * @return
     */
    Self selectByResId(Integer resId);

    /**
     * 修改自我评价
     * @param self
     * @return
     */
    int updateById(Self self);

    /**
     * 删除自我评价
     * @param id
     * @return
     */
    int deleteById(Integer id);

}