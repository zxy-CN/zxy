package cn.job.mapper;

import cn.job.entity.Skill;

import java.util.ArrayList;

public interface SkillMapper {

    /**
     * 增加一条专业技能
     * @param skill
     * @return
     */
    int insert(Skill skill);

    /**
     * 根据简历id查询专业技能
     * @param resId
     * @return
     */
    Skill selectByResId(Integer resId);

    /**
     * 修改专业技能
     * @param skill
     * @return
     */
    int updateById(Skill skill);

    /**
     * 删除专业技能
     * @param id
     * @return
     */
    int deleteById(Integer id);


}