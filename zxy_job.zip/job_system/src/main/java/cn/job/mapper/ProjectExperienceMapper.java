package cn.job.mapper;

import cn.job.entity.ProjectExperience;

import java.util.ArrayList;

public interface ProjectExperienceMapper {

    /**
     * 添加项目/实践经验
     * @param projectExperience
     * @return
     */
    int insert(ProjectExperience projectExperience);

    /**
     * 根据简历id查询项目/实践经验
     * @param resId
     * @return
     */
    ProjectExperience selectByResId(Integer resId);

    /**
     * 修改项目经验
     * @param projectExperience
     * @return
     */
    int updateById(ProjectExperience projectExperience);

    /**
     * 删除项目经验
     * @param id
     * @return
     */
    int deleteById(Integer id);

}