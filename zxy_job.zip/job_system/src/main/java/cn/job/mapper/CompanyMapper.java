package cn.job.mapper;

import cn.job.entity.Company;

import java.util.ArrayList;

public interface CompanyMapper {
    int deleteByPrimaryKey(Integer id);

    /**
     * 添加企业信息
     * @param company
     * @return
     */
    int insert(Company company);

    int insertSelective(Company record);

    /**
     * 根据用户id查询企业信息
     * @param uid
     * @return
     */
    Company selectByUid(Integer uid);

    /**
     * 根据id查询企业信息
     * @param id
     * @return
     */
    Company selectById(Integer id);

    int updateByPrimaryKeySelective(Company record);

    /**
     * 修改企业信息
     * @param company
     * @return
     */
    int updateByUid(Company company);

    /**
     * 认证企业
     * @param uid
     * @return
     */
    int updateComPass(Integer uid);

    /**
     * 根据企业名字查询企业
     * @param name
     * @return
     */
    ArrayList<Company> selectByName(String name);
}