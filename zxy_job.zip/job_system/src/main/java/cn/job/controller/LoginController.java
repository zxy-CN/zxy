package cn.job.controller;

import cn.job.entity.JsonResult;
import cn.job.entity.Resume;
import cn.job.entity.User;
import cn.job.service.ResumeService;
import cn.job.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;

/**
 * 登录的控制器
 */
@RestController
public class LoginController {
    @Autowired
    private UserService userService;
    @Autowired
    private ResumeService resumeService;

    /**
     * 登录，将对象传递到前端，根据对象的type属性进行跳转
     * @param uname
     * @param upwd
     * @param session
     * @return
     */
    @RequestMapping("/login")
    public JsonResult<User> login(@RequestParam("uname") String uname, @RequestParam("upwd") String upwd, HttpSession session){
        User user=userService.login(uname,upwd);
        if (user!=null){
            session.setAttribute("loginUser",user);
            return new JsonResult<>("ok",user);
        }else {
            return new JsonResult<>("err",null);
        }
    }
    /**
     * 退出时清除session
     * @param session
     */
    @RequestMapping("/clear")
    public void clear(HttpSession session){
        session.invalidate();
    }
    /**
     * 取session
     * @param session
     * @return
     */
    @RequestMapping("/gets")
    public JsonResult<User> get(HttpSession session){
        User user=(User) session.getAttribute("loginUser");
        if (user!=null){
            return  new JsonResult<>("ok",user);
        }
        return  new JsonResult<>("err",null);
    }

    /**
     * 学生注册
     * @param uname
     * @param upwd
     * @return
     */
    @RequestMapping("/reg/stu")
    public JsonResult<User> registerStu(@RequestParam("uname") String uname, @RequestParam("upwd") String upwd){
        User user=new User(uname,upwd,"学生",1);
        int rs=userService.registerStu(user);
        if (rs!=0){
            User user1=userService.login(uname,upwd);
            Integer uid=user1.getId();
            Resume resume=new Resume("简历",uid);
            int rs1=resumeService.addRes(resume);
            return new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }

    /**
     * 企业注册
     * @param uname
     * @param upwd
     * @return
     */
    @RequestMapping("/reg/com")
    public JsonResult<User> registerCom(@RequestParam("uname") String uname, @RequestParam("upwd") String upwd){
        User user=new User(uname,upwd,"企业",1);
        int rs=userService.registerStu(user);
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }

    @RequestMapping("/upwd")
    public JsonResult<User> updatePwd(@RequestBody User user){
        int rs=userService.updatePwd(user);
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }
}
