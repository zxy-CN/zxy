package cn.job.controller;

import cn.job.entity.Company;
import cn.job.entity.Job;
import cn.job.entity.JsonResult;
import cn.job.service.CompanyService;
import cn.job.service.JobService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

/**
 * 职位的控制器
 */
@RestController
public class JobController {
    @Autowired
    private JobService jobService;
    @Autowired
    private CompanyService companyService;

    /**
     * 模糊查询职位
     * @param pageNum
     * @param keys
     * @return
     */
    @RequestMapping("/get/jobs/key")
    public JsonResult<PageInfo<Job>> getJobsBykey(@RequestParam("pageNum") Integer pageNum ,@RequestParam("keys") String keys){
        PageInfo<Job> jobs=jobService.getJobsBykeys(pageNum,8,keys);
        if (jobs!=null){
            return new JsonResult<>("ok",jobs);
        }
        return new JsonResult<>("nodata",null);
    }

    /**
     * 发布职位的方法
     * @return
     */
    @RequestMapping("/add/job")
    public JsonResult<Job> addJob(@RequestBody Job job){
        int rs=jobService.addJob(job);
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }

    /**
     * 修改职位
     * @param job
     * @return
     */
    @RequestMapping("/update/job")
    public JsonResult<Job> updateJob(@RequestBody Job job){
        int rs=jobService.updateJob(job);
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }

    /**
     * 删除职位
     * @param id
     * @return
     */
    @RequestMapping("/del/job")
    public JsonResult<Job> delJob(@RequestParam("id") Integer id){
        int rs=jobService.delJob(id);
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }

    /**
     * 根据职位id查找职位
     * @param id
     * @return
     */
    @RequestMapping("/get/job")
    public JsonResult<Job> getJob(@RequestParam("id") Integer id){
        Job job=jobService.getJobById(id);
        Integer comid=job.getComid();
        Company company=companyService.getComInfById(comid);
        job.setCompany(company);
        if (job!=null){
            return new JsonResult<>("ok",job);
        }
        return new JsonResult<>("nodata",null);
    }

    /**
     * 根据企业id查询企业已经发布的职位
     * @param comId
     * @return
     */
    @RequestMapping("/get/jobs")
    public JsonResult<ArrayList<Job>> getJobs(@RequestParam("comId") Integer comId){
        ArrayList<Job> jobs=jobService.getJobsBycomId(comId);
        if (jobs.size()!=0 && jobs!=null){
            return new JsonResult<>("ok",jobs);
        }
        return new JsonResult<>("nodata",null);
    }


}
