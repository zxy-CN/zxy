package cn.job.controller;

import cn.job.entity.JsonResult;
import cn.job.entity.Teach;
import cn.job.service.TeachService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

/**
 * 宣讲会的控制器
 */
@RestController
public class TeachController {
    @Autowired
    private TeachService teachService;

    /**
     * 添加一个宣讲会
     * @param teach
     * @return
     */
    @RequestMapping("/add/tea")
    public JsonResult<String> addTea(@RequestBody Teach teach){
        int rs=teachService.creTeach(teach);
        if (rs!=0){
            return  new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }

    /**
     * 修改宣讲会信息
     * @param teach
     * @return
     */
    @RequestMapping("/edit/tea")
    public JsonResult<String> editTea(@RequestBody Teach teach){
        int rs=teachService.updateTeach(teach);
        if (rs!=0){
            return  new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }

    /**
     * 删除此宣讲会
     * @param id
     * @return
     */
    @RequestMapping("/del/tea")
    public JsonResult<String> delTea(@RequestParam("id") Integer id){
        int rs=teachService.delTeach(id);
        if (rs!=0){
            return  new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }

    /**
     * 每个公司查看自己发布的宣讲会
     * @param comId
     * @return
     */
    @RequestMapping("/get/teas")
    public JsonResult<ArrayList<Teach>> getTeaByComId(@RequestParam("comid") Integer comId){
        ArrayList<Teach> teaches=teachService.getTeaByComId(comId);
        if (teaches.size()!=0){
            return  new JsonResult<>("ok",teaches);
        }
        return new JsonResult<>("nodata",null);
    }

    /**
     * 模糊查询宣讲会
     * @param pageNum
     * @param keys
     * @return
     */
    @RequestMapping("/get/tea/key")
    public JsonResult<PageInfo<Teach>> getJobsBykey(@RequestParam("pageNum") Integer pageNum , @RequestParam("keys") String keys){
        PageInfo<Teach> teas=teachService.getJobsBykeys(pageNum,8,keys);
        if (teas!=null){
            return new JsonResult<>("ok",teas);
        }
        return new JsonResult<>("nodata",null);
    }


}
