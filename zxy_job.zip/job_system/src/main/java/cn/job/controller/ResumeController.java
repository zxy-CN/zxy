package cn.job.controller;

import cn.job.entity.*;
import cn.job.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * 简历的控制器
 */
@RestController
public class ResumeController {
    @Autowired
    private ResumeService resumeService;
    @Autowired
    private StudentService studentService;
    @Autowired
    private JobforService jobforService;
    @Autowired
    private EduExperienceService eduExperienceService;
    @Autowired
    private SchoolExperienceService schoolExperienceService;
    @Autowired
    private SkillService skillService;
    @Autowired
    private ProjectExperienceService projectExperienceService;
    @Autowired
    private SelfService selfService;

    /**
     * 查询简历
     * @param uid
     * @return
     */
    @RequestMapping("/get/res")
    public JsonResult<Resume> getRes(@RequestParam("uid") Integer uid){
        Resume resume=resumeService.getRes(uid);
        if(resume!=null){
            return new JsonResult<>("ok" ,resume);
        }
        return new JsonResult<>("nodata",null);
    }

    /**
     * 查询简历
     * @param id
     * @return
     */
    @RequestMapping("/get/byid")
    public JsonResult<Resume> getResById(@RequestParam("id") Integer id){
        Resume resume=resumeService.getResById(id);
        if(resume!=null){
            return new JsonResult<>("ok" ,resume);
        }
        return new JsonResult<>("nodata",null);
    }

    /**
     * 修改简历名
     * @param resume
     * @return
     */
    @RequestMapping("/edit/res")
    public JsonResult<Resume> getRes(@RequestBody Resume resume){
        int rs=resumeService.editRes(resume);
        if(rs!=0){
            return new JsonResult<>("ok" ,null);
        }
        return new JsonResult<>("nodata",null);
    }
    /**
     * 根据简历对象查询简历的详细
     * @param resume
     * @return
     */
    @RequestMapping("/get/res/detail")
    public JsonResult<Map> getPersonInf(@RequestBody Resume resume){
        HashMap<String,Object> map=new HashMap<>();
        Integer uid=resume.getUid();
        Integer resId=resume.getId();
        Student student=studentService.getStuInf(uid);
        Jobfor jobfor=jobforService.getJobfor(resId);
        EduExperience eduExperience=eduExperienceService.getEdus(resId);
        SchoolExperience schoolExperience=schoolExperienceService.getSchExps(resId);
        Skill skill=skillService.getSkills(resId);
        ProjectExperience projectExperience=projectExperienceService.getProExp(resId);
        Self self=selfService.getSelf(resId);
        if (student!=null){
            map.put("stuinf",student);
        }
        if (jobfor!=null){
            map.put("jobfor",jobfor);
        }
        if (self!=null){
            map.put("self",self);
        }
        map.put("eduexp",eduExperience);
        map.put("schexp",schoolExperience);
        map.put("skill",skill);
        map.put("proexp",projectExperience);
        return  new JsonResult<>("ok",map);
    }

//    /**
//     * 添加求职意向
//     * @param jobfor
//     * @return
//     */
//    @RequestMapping("/add/jobfor")
//    public JsonResult<String> addJobfor(@RequestBody Jobfor jobfor){
//        int rs=jobforService.addJobfor(jobfor);
//        if (rs!=0){
//            return new JsonResult<>("ok",null);
//        }
//        return  new JsonResult<>("err",null);
//    }

    /**
     * 根据此对象是否存在而进行创建或者修改的方法
     * @param jobfor
     * @return
     */
    @RequestMapping("/addored/jobfor")
    public JsonResult<String> addJOrEditobfor(@RequestBody Jobfor jobfor){
        Integer resId=jobfor.getResid();
        Jobfor jobfor1=jobforService.getJobfor(resId);
        if (jobfor1!=null){
            Integer id=jobfor1.getId();
            jobfor.setId(id);
            int rs=jobforService.editJobfor(jobfor);
            if (rs!=0){
                return new JsonResult<>("ok",null);
            }
            return  new JsonResult<>("err",null);
        }else {
            int rs=jobforService.addJobfor(jobfor);
            if (rs!=0){
                return new JsonResult<>("ok",null);
            }
            return  new JsonResult<>("err",null);
        }
    }



    /**
     * 删除求职意向
     * @param id
     * @return
     */
    @RequestMapping("/del/jobfor")
    public JsonResult<String> delJobfor(@RequestParam("id") Integer id){
        int rs=jobforService.delJobfor(id);
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return  new JsonResult<>("err",null);
    }

    /**
     * 添加教育经历
     * @param eduExperience
     * @return
     */
    @RequestMapping("/add/edu")
    public JsonResult<String> addEdu(@RequestBody EduExperience eduExperience){
        int rs=0;
        Integer resid=eduExperience.getResid();
        EduExperience eduExperience1=eduExperienceService.getEdus(resid);
        if (eduExperience1!=null){
            eduExperience.setId(eduExperience1.getId());
             rs=eduExperienceService.editEdu(eduExperience);
        }else {
            rs=eduExperienceService.addEdu(eduExperience);
        }
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return  new JsonResult<>("err",null);
    }

    /**
     * 删除教育经历
     * @param id
     * @return
     */
    @RequestMapping("/del/edu")
    public JsonResult<String> delEdu(@RequestParam("id") Integer id){
        int rs=eduExperienceService.delEdu(id);
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return  new JsonResult<>("err",null);
    }

    /**
     * 会根据是否存在而判断是修改还是添加
     * @param schoolExperience
     * @return
     */
    @RequestMapping("/add/schexp")
    public JsonResult<String> addSchExp(@RequestBody SchoolExperience schoolExperience){
        int rs=0;
        Integer resId=schoolExperience.getResid();
        SchoolExperience schoolExperience1=schoolExperienceService.getSchExps(resId);
        if (schoolExperience1!=null){
            schoolExperience.setId(schoolExperience1.getId());
            rs=schoolExperienceService.editSchExp(schoolExperience);
        }else {
             rs=schoolExperienceService.addSchExp(schoolExperience);
        }
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return  new JsonResult<>("err",null);
    }

    /**
     * 删除校园经历
     * @param id
     * @return
     */
    @RequestMapping("/del/schexp")
    public JsonResult<String> delSchExp(@RequestParam("id") Integer id){
        int rs=schoolExperienceService.delSchExp(id);
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return  new JsonResult<>("err",null);
    }

    /**
     * 添加专业技能
     * @param skill
     * @return
     */
    @RequestMapping("/add/skill")
    public JsonResult<String> addSkill(@RequestBody Skill skill){
        int rs=0;
        Integer resId=skill.getResid();
        Skill skill1=skillService.getSkills(resId);
        if (skill1!=null){
            skill.setId(skill1.getId());
            rs=skillService.editSkill(skill);
        }else {
             rs=skillService.addSkill(skill);
        }
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return  new JsonResult<>("err",null);
    }

//    /**
//     * 修改专业技能
//     * @param skill
//     * @return
//     */
//    @RequestMapping("/edit/skill")
//    public JsonResult<String> editSkill(@RequestBody Skill skill){
//        int rs=skillService.editSkill(skill);
//        if (rs!=0){
//            return new JsonResult<>("ok",null);
//        }
//        return  new JsonResult<>("err",null);
//    }

    /**
     * 删除专业技能
     * @param id
     * @return
     */
    @RequestMapping("/del/skill")
    public JsonResult<String> delSkill(@RequestParam("id") Integer id){
        int rs=skillService.delSkill(id);
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return  new JsonResult<>("err",null);
    }

    /**
     * 添加项目/实践经验
     * @param projectExperience
     * @return
     */
    @RequestMapping("/add/proexp")
    public JsonResult<String> addProExp(@RequestBody ProjectExperience projectExperience){
        int rs=0;
        Integer resId=projectExperience.getResid();
        ProjectExperience projectExperience1=projectExperienceService.getProExp(resId);
        if (projectExperience1!=null){
            projectExperience.setId(projectExperience1.getId());
             rs=projectExperienceService.editProExp(projectExperience);
        }else {
             rs=projectExperienceService.addProExp(projectExperience);
        }
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return  new JsonResult<>("err",null);
    }

    /**
     * 删除项目经验
     * @param id
     * @return
     */
    @RequestMapping("/del/proexp")
    public JsonResult<String> delProExp(@RequestParam("id") Integer id){
        int rs=projectExperienceService.delProExp(id);
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return  new JsonResult<>("err",null);
    }

    /**
     * 添加自我评价
     * @param self
     * @return
     */
    @RequestMapping("/add/self")
    public JsonResult<String> addSelf(@RequestBody Self self){
        int rs=0;
        Integer resid=self.getResid();
        Self self1=selfService.getSelf(resid);
        if (self1!=null){
            self.setId(self1.getId());
            rs=selfService.editSelf(self);
        }else {
            rs=selfService.addSelf(self);
        }
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return  new JsonResult<>("err",null);
    }
    /**
     * 删除自我评价
     * @param id
     * @return
     */
    @RequestMapping("/del/self")
    public JsonResult<String> delSelf(@RequestParam("id") Integer id){
        int rs=selfService.delSelf(id);
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return  new JsonResult<>("err",null);
    }
}
