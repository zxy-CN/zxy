package cn.job.controller;

import cn.job.entity.JsonResult;
import cn.job.entity.Student;
import cn.job.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 学生信息的控制器
 */
@RestController
public class StudentController {
    @Autowired
    private StudentService studentService;
    /**
     * 添加学生信息
     * @param student
     * 参数是前端用vue封装的student对象
     * @return
     */
    @RequestMapping("/add/stuinf")
    public JsonResult<Student> addStuInf(@RequestBody Student student){
        int rs=0;
        Integer uid=student.getUid();
        Student student1=studentService.getStuInf(uid);
        if (student1!=null){
             rs=studentService.updateStuInf(student);
        }else {
             rs=studentService.addStuInf(student);
        }
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }

//    /**
//     * 修改学生信息
//     * @param student
//     * 参数是前端用vue封装的student对象
//     * @return
//     */
//    @RequestMapping("/update/stuinf")
//    public JsonResult<Student> updateStuInf(@RequestBody Student student){
//        int rs=studentService.updateStuInf(student);
//        if (rs!=0){
//            return new JsonResult<>("ok",null);
//        }
//        return new JsonResult<>("err",null);
//    }

    /**
     * 根据用户id获取学生信息
     * @param uid
     * @return
     */
    @RequestMapping("/get/stuinf")
    public JsonResult<Student> getStuInf(@RequestParam("uid") Integer uid){
        Student student=studentService.getStuInf(uid);
        if (student!=null){
            return new JsonResult<>("ok",student);
        }
        return new JsonResult<>("nodate",null);
    }
}
