package cn.job.controller;

import cn.job.entity.*;
import cn.job.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * 投递的控制器
 */
@RestController
public class SendController {
    @Autowired
    private SendService sendService;
    @Autowired
    private JobService jobService;
    @Autowired
    private ResumeService resumeService;
    @Autowired
    private CompanyService companyService;
    @Autowired
    private StudentService studentService;

    /**
     * 投递一份简历
     * @param send
     * @return
     */
    @RequestMapping("/send/res")
    public JsonResult<String> creSend(@RequestBody Send send){
        int rs=sendService.insert(send);
        if (rs!=0){
            return  new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }

    @RequestMapping("/get/sends")
    public JsonResult<ArrayList<Send>> getSend(@RequestBody Send send){
        ArrayList<Send> sends=sendService.sel(send);
        if (sends.size()!=0){
            for(int i=0;i<sends.size();i++){
                Send send1=sends.get(i);
                Integer jobid=send1.getJobid();
                Integer resId=send1.getResid();
                Job job=jobService.getJobById(jobid);
                Integer comid=job.getComid();
                Company company=companyService.getComInfById(comid);
                job.setCompany(company);
                send1.setJob(job);
                Resume resume=resumeService.getResById(resId);
                send1.setResume(resume);
            }
            return  new JsonResult<>("ok",sends);
        }
        return new JsonResult<>("err",null);
    }

    @RequestMapping("/get/sends/com")
    public JsonResult<ArrayList<Send>> sendManage(@RequestBody Send send){
        ArrayList<Send> sends=sendService.selByJobId(send);
        if (sends.size()!=0){
            for(int i=0;i<sends.size();i++){
                Send send1=sends.get(i);
                Integer resId=send1.getResid();
                Resume resume=resumeService.getResById(resId);
                Integer uid=resume.getUid();
                Student student=studentService.getStuInf(uid);
                send1.setStudent(student);
                send1.setResume(resume);
            }
            return  new JsonResult<>("ok",sends);
        }
        return new JsonResult<>("err",null);
    }

    /**
     * 查看该简历后将状态改变,已查看
     * @param send
     * @return
     */
    @RequestMapping("/send/see")
    public JsonResult<String> SendSee(@RequestBody Send send){
        send.setState("已查看");
        int rs=sendService.update(send);
        if (rs!=0){
            return  new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }

    /**
     * 查看该简历后将状态改变，感兴趣
     * @param send
     * @return
     */
    @RequestMapping("/send/want")
    public JsonResult<String> SendWant(@RequestBody Send send){
        send.setState("感兴趣");
        int rs=sendService.update(send);
        if (rs!=0){
            return  new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }

    /**
     * 查看该简历后将状态改变，录取
     * @param send
     * @return
     */
    @RequestMapping("/send/get")
    public JsonResult<String> SendGet(@RequestBody Send send){
        send.setState("通知面试");
        int rs=sendService.update(send);
        if (rs!=0){
            return  new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }

    /**
     * 查看该简历后将状态改变，不合适
     * @param send
     * @return
     */
    @RequestMapping("/send/not")
    public JsonResult<String> SendNot(@RequestBody Send send){
        send.setState("不合适");
        int rs=sendService.update(send);
        if (rs!=0){
            return  new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }
}
