package cn.job.controller;

import cn.job.entity.Company;
import cn.job.entity.JsonResult;
import cn.job.service.CompanyService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 企业信息的控制器
 */
@RestController
public class CompanyController {
    @Autowired
    private CompanyService companyService;

    /**
     * 添加企业信息
     * @param company
     * 参数由前端用vue封装的company对象
     * @return
     */
    @RequestMapping("/add/cominf")
    public JsonResult<Company> addComInf(@RequestBody Company company){
        int rs=0;
        Integer uid=company.getUid();
        Company company1=companyService.getComInf(uid);
        if (company1!=null){
            rs=companyService.updateComInf(company);
        }else {
            rs=companyService.addComInf(company);
        }
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }

//    /**
//     * 修改企业信息
//     * @param company
//     * 由前端vue封装企业对象传递
//     * @return
//     */
//    @RequestMapping("/update/cominf")
//    public JsonResult<Company> updateComInf(@RequestBody Company company){
//
//        if (rs!=0){
//            return new JsonResult<>("ok",null);
//        }
//        return new JsonResult<>("err",null);
//    }

    /**
     * 根据uid查询企业信息
     * @param uid
     * @return
     */
    @RequestMapping("/get/cominf")
    public JsonResult<Company> getComInf(@RequestParam("uid") Integer uid){
        Company company=companyService.getComInf(uid);
        if (company!=null){
            return new JsonResult<>("ok",company);
        }
        return  new JsonResult<>("nodata",null);
    }

    /**
     * 根据id查询企业信息
     * @param id
     * @return
     */
    @RequestMapping("/get/cominfbyid")
    public JsonResult<Company> getComInfById(@RequestParam("id") Integer id){
        Company company=companyService.getComInfById(id);
        if (company!=null){
            return new JsonResult<>("ok",company);
        }
        return  new JsonResult<>("nodata",null);
    }

    /**
     * 根据名字查询企业 模糊查询
     * @param pageNum
     * @param comName
     * @return
     */
    @RequestMapping("/get/coms")
    public JsonResult<PageInfo<Company>> getJobsBykey(@RequestParam("pageNum") Integer pageNum , @RequestParam("keys") String comName ){
        PageInfo<Company> coms=companyService.getComsByName(pageNum,8,comName);
        if (coms!=null){
            return new JsonResult<>("ok",coms);
        }
        return new JsonResult<>("nodata",null);
    }
    /**
     * 认证企业
     * @param uid
     * @return
     */
    @RequestMapping("/update/compass")
    public JsonResult<Company> updateComPass(@RequestParam("uid") Integer uid){
        int rs=companyService.updateComPass(uid);
        if (rs!=0){
            return new JsonResult<>("ok",null);
        }
        return new JsonResult<>("err",null);
    }
}
