package cn.job.service;

import cn.job.entity.Skill;

import java.util.ArrayList;

/**
 * 专业技能的业务层接口
 */
public interface SkillService {
    /**
     * 添加专业技能
     * @param skill
     * @return
     */
    int addSkill(Skill skill);

    /**
     * 根据简历id查询专业技能
     * @param resId
     * @return
     */
    Skill getSkills(Integer resId);

    /**
     * 修改专业技能
     * @param skill
     * @return
     */
    int editSkill(Skill skill);

    /**
     * 删除专业技能
     * @param id
     * @return
     */
    int delSkill(Integer id);
}
