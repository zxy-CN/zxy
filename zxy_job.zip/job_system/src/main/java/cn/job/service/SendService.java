package cn.job.service;

import cn.job.entity.Send;

import java.util.ArrayList;

/**
 * 投递的业务层接口
 */
public interface SendService {
    /**
     * 投递简历（即创建一个新的简历）
     * @param send
     * @return
     */
    int insert(Send send);

    /**
     * 修改简历的投递状态
     * @param send
     * @return
     */
    int update(Send send);

    ArrayList<Send> sel(Send send);

    ArrayList<Send> selByJobId(Send send);
}
