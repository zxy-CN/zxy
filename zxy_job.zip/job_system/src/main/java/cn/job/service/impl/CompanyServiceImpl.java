package cn.job.service.impl;

import cn.job.entity.Company;
import cn.job.mapper.CompanyMapper;
import cn.job.service.CompanyService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service("companyService")
public class CompanyServiceImpl implements CompanyService {
    @Autowired
    private CompanyMapper companyMapper;
    @Override
    public int addComInf(Company company) {
        return companyMapper.insert(company);
    }

    @Override
    public int updateComInf(Company company) {
        return companyMapper.updateByUid(company);
    }

    @Override
    public Company getComInf(Integer uid) {
        return companyMapper.selectByUid(uid);
    }

    @Override
    public Company getComInfById(Integer id) {
        return companyMapper.selectById(id);
    }

    @Override
    public int updateComPass(Integer uid) {
        return companyMapper.updateComPass(uid);
    }

    @Override
    public PageInfo<Company> getComsByName(int pageNum, int pageSize, String name) {
        PageHelper.startPage(pageNum,pageSize);
        ArrayList<Company> companies=companyMapper.selectByName(name);
        PageInfo<Company> pageInfo=new PageInfo<>(companies);
        return  pageInfo;
    }
}
