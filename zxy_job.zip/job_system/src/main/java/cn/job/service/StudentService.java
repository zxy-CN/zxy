package cn.job.service;

import cn.job.entity.Student;

/**
 * 学生信息的业务层接口
 */

public interface StudentService {
    /**
     * 添加学生信息
     * @param student
     * @return
     */
    int addStuInf(Student student);

    /**
     * 修改学生信息
     * @param student
     * @return
     */
    int updateStuInf(Student student);

    /**
     * 查询学生信息
     * @param uid
     * @return
     */
    Student getStuInf(Integer uid);

    /**
     * 通过id查询学生信息
     * @param id
     * @return
     */
    Student getStuById(Integer id);
}
