package cn.job.service;

import cn.job.entity.Jobfor;

/**
 * 求职意向的业务层接口
 */
public interface JobforService {
    /**
     * 添加一个求职意向
     * @param jobfor
     * @return
     */
    int addJobfor(Jobfor jobfor);

    /**
     * 根据简历id查询求职意向
     * @param resId
     * @return
     */
    Jobfor getJobfor(Integer resId);

    /**
     * 修改求职意向
     * @param jobfor
     * @return
     */
    int editJobfor(Jobfor jobfor);

    /**
     * 删除工作意向
     * @param id
     * @return
     */
    int delJobfor(Integer id);
}
