package cn.job.service.impl;

import cn.job.entity.Skill;
import cn.job.mapper.SkillMapper;
import cn.job.service.SkillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service("skillService")
public class SkillServiceImpl implements SkillService {
    @Autowired
    private SkillMapper skillMapper;
    @Override
    public int addSkill(Skill skill) {
        return skillMapper.insert(skill);
    }

    @Override
    public Skill getSkills(Integer resId) {
        return skillMapper.selectByResId(resId);
    }

    @Override
    public int editSkill(Skill skill) {
        return skillMapper.updateById(skill);
    }

    @Override
    public int delSkill(Integer id) {
        return skillMapper.deleteById(id);
    }
}
