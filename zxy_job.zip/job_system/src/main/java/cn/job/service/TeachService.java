package cn.job.service;

import cn.job.entity.Teach;
import com.github.pagehelper.PageInfo;

import java.util.ArrayList;

/**
 * 宣讲会的业务层接口
 */
public interface TeachService {
    /**
     * 添加一个宣讲会
     * @param teach
     * @return
     */
    int creTeach(Teach teach);

    /**
     * 通过id修改此宣讲会的信息
     * @param teach
     * @return
     */
    int updateTeach(Teach teach);

    /**
     * 通过id删除此宣讲会
     * @param id
     * @return
     */
    int delTeach(Integer id);

    /**
     * 通过企业id查询发布的宣讲会
     * @param comId
     * @return
     */
    ArrayList<Teach> getTeaByComId(Integer comId);

    /**
     * 根据关键字模糊查询职位
     * @param keys
     * @return
     */
    PageInfo<Teach> getJobsBykeys(int pageNum, int pageSize, String keys);
}
