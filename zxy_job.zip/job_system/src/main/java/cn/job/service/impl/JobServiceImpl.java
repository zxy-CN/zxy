package cn.job.service.impl;

import cn.job.entity.Company;
import cn.job.entity.Job;
import cn.job.mapper.CompanyMapper;
import cn.job.mapper.JobMapper;
import cn.job.service.JobService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

/**
 * 职位的业务层接口实现类
 */
@Service("jobService")
public class JobServiceImpl implements JobService {
    @Autowired
    private JobMapper jobMapper;
    @Autowired
    private CompanyMapper companyMapper;

    @Override
    public PageInfo<Job> getJobsBykeys(int pageNum, int pageSize, String keys) {
        PageHelper.startPage(pageNum,pageSize);//用来设定显示接口起始页码和页容量的方法
        ArrayList<Job> jobs=jobMapper.selectByKeys(keys);//调用接口中的方法，将查询结果赋值给jobs。
        for (int i=0;i<jobs.size();i++){
            Job job=jobs.get(i);
            Integer comId=job.getComid();
            Company company=companyMapper.selectById(comId);
            job.setCompany(company);
        }//根据查询结果中的企业id查询相应的企业信息，并添加进job对象中。
        PageInfo<Job> pageInfo=new PageInfo<>(jobs);//将jos赋值给pageinfo。
        return pageInfo;
    }

    @Override
    public int addJob(Job job) {
        return jobMapper.insert(job);
    }

    @Override
    public int updateJob(Job job) {
        return jobMapper.updateById(job);
    }

    @Override
    public int delJob(Integer id) {
        return jobMapper.delById(id);
    }

    @Override
    public Job getJobById(Integer id) {
        return jobMapper.selectById(id);
    }

    @Override
    public ArrayList<Job> getJobsBycomId(Integer comId) {
        return jobMapper.selectBycomId(comId);
    }


}
