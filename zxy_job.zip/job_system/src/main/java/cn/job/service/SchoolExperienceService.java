package cn.job.service;

import cn.job.entity.SchoolExperience;

import java.util.ArrayList;

/**
 * 校园经历的业务层接口
 */
public interface SchoolExperienceService {
    /**
     * 添加校园经历
     * @param schoolExperience
     * @return
     */
    int addSchExp(SchoolExperience schoolExperience);

    /**
     * 根据简历id查询校园经历
     * @param resId
     * @return
     */
    SchoolExperience getSchExps(Integer resId);

    /**
     * 修改校园经历
     * @param schoolExperience
     * @return
     */
    int editSchExp(SchoolExperience schoolExperience);

    /**
     * 删除校园经历
     * @param id
     * @return
     */
    int delSchExp(Integer id);
}
