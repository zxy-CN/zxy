package cn.job.service;

import cn.job.entity.EduExperience;

import java.util.ArrayList;

/**
 * 教育经历的业务层接口
 */
public interface EduExperienceService {
    /**
     * 添加一个教育经历
     * @param eduExperience
     * @return
     */
    int addEdu(EduExperience eduExperience);

    /**
     * 根据简历id查询教育经历
     * @param resId
     * @return
     */
    EduExperience getEdus(Integer resId);

    /**
     * 修改教育经历
     * @param eduExperience
     * @return
     */
    int editEdu(EduExperience eduExperience);

    /**
     * 删除教育经历
     * @param id
     * @return
     */
    int delEdu(Integer id);
}
