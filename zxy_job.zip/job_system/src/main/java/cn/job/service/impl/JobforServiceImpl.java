package cn.job.service.impl;

import cn.job.entity.Jobfor;
import cn.job.mapper.JobforMapper;
import cn.job.service.JobforService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("jobforService")
public class JobforServiceImpl implements JobforService {
    @Autowired
    private JobforMapper jobforMapper;
    @Override
    public int addJobfor(Jobfor jobfor) {
        return jobforMapper.insert(jobfor);
    }

    @Override
    public Jobfor getJobfor(Integer resId) {
        return jobforMapper.selectByResId(resId);
    }

    @Override
    public int editJobfor(Jobfor jobfor) {
        return jobforMapper.updateById(jobfor);
    }

    @Override
    public int delJobfor(Integer id) {
        return jobforMapper.deleteById(id);
    }
}
