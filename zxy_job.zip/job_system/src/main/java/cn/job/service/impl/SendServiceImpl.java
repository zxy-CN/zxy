package cn.job.service.impl;

import cn.job.entity.Send;
import cn.job.mapper.SendMapper;
import cn.job.service.SendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service("sendService")
public class SendServiceImpl implements SendService {
    @Autowired
    private SendMapper sendMapper;
    @Override
    public int insert(Send send) {
        return sendMapper.insert(send);
    }

    @Override
    public int update(Send send) {
        return sendMapper.updateById(send);
    }

    @Override
    public ArrayList<Send> sel(Send send) {
        return sendMapper.selectByResId(send);
    }

    @Override
    public ArrayList<Send> selByJobId(Send send) {
        return sendMapper.selectByJobId(send);
    }
}
