package cn.job.service.impl;

import cn.job.entity.Student;
import cn.job.mapper.StudentMapper;
import cn.job.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("studentService")
public class StudentServiceImpl implements StudentService {
    @Autowired
    private StudentMapper studentMapper;
    @Override
    public int addStuInf(Student student) {
        return studentMapper.insert(student);
    }

    @Override
    public int updateStuInf(Student student) {
        return studentMapper.updateByUId(student);
    }

    @Override
    public Student getStuInf(Integer uid) {
        return studentMapper.selectByUid(uid);
    }

    @Override
    public Student getStuById(Integer id) {
        return studentMapper.selectById(id);
    }
}
