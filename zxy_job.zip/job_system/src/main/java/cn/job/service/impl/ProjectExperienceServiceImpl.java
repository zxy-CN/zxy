package cn.job.service.impl;

import cn.job.entity.ProjectExperience;
import cn.job.mapper.ProjectExperienceMapper;
import cn.job.service.ProjectExperienceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service("projectExperienceService")
public class ProjectExperienceServiceImpl implements ProjectExperienceService {
    @Autowired
    private ProjectExperienceMapper projectExperienceMapper;
    @Override
    public int addProExp(ProjectExperience projectExperience) {
        return projectExperienceMapper.insert(projectExperience);
    }

    @Override
    public ProjectExperience getProExp(Integer resId) {
        return projectExperienceMapper.selectByResId(resId);
    }

    @Override
    public int editProExp(ProjectExperience projectExperience) {
        return projectExperienceMapper.updateById(projectExperience);
    }

    @Override
    public int delProExp(Integer id) {
        return projectExperienceMapper.deleteById(id);
    }
}
