package cn.job.service.impl;

import cn.job.entity.Self;
import cn.job.mapper.SelfMapper;
import cn.job.service.SelfService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("selfService")
public class SelfServiceImpl implements SelfService {
    @Autowired
    private SelfMapper selfMapper;
    @Override
    public int addSelf(Self self) {
        return selfMapper.insert(self);
    }

    @Override
    public Self getSelf(Integer resId) {
        return selfMapper.selectByResId(resId);
    }

    @Override
    public int editSelf(Self self) {
        return selfMapper.updateById(self);
    }

    @Override
    public int delSelf(Integer id) {
        return selfMapper.deleteById(id);
    }
}
