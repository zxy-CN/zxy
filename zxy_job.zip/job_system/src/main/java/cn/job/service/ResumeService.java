package cn.job.service;

import cn.job.entity.Resume;

/**
 * 简历的业务层接口
 */
public interface ResumeService {
    /**
     * 添加一份简历
     * @param resume
     * @return
     */
    int addRes(Resume resume);

    /**
     * 根据uid搜索简历
     * @param uid
     * @return
     */
    Resume getRes(Integer uid);

    int editRes(Resume resume);

    Resume getResById(Integer id);
}
