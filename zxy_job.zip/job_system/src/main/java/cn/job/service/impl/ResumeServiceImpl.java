package cn.job.service.impl;

import cn.job.entity.Resume;
import cn.job.mapper.ResumeMapper;
import cn.job.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 简历的业务层接口实现类
 */
@Service("resumeService")
public class ResumeServiceImpl implements ResumeService{
    @Autowired
    private ResumeMapper resumeMapper;
    @Override
    public int addRes(Resume resume) {
        return resumeMapper.insert(resume);
    }

    @Override
    public Resume getRes(Integer uid) {
        return resumeMapper.selectByUid(uid);
    }

    @Override
    public int editRes(Resume resume) {
        return resumeMapper.updateId(resume);
    }

    @Override
    public Resume getResById(Integer id) {
        return resumeMapper.selectById(id);
    }
}
