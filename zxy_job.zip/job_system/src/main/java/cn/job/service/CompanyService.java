package cn.job.service;

import cn.job.entity.Company;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 企业的业务层接口
 */
public interface CompanyService {
    /**
     * 添加企业信息
     * @param company
     * @return
     */
    int addComInf(Company company);

    /**
     * 修改企业信息
     * @param company
     * @return
     */
    int updateComInf(Company company);

    /**
     * 根据uid查询企业信息
     * @param uid
     * @return
     */
    Company getComInf(Integer uid);

    /**
     * 根据id查询企业信息
     * @param id
     * @return
     */
    Company getComInfById(Integer id);

    /**
     * 认证企业
     * @param uid
     * @return
     */
    int updateComPass(Integer uid);

    /**
     * 根据关键字模糊查询企业
     * @param name
     * @return
     */
    PageInfo<Company> getComsByName(int pageNum, int pageSize, String name);
}
