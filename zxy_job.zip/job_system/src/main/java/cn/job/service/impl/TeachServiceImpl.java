package cn.job.service.impl;

import cn.job.entity.Company;
import cn.job.entity.Teach;
import cn.job.mapper.CompanyMapper;
import cn.job.mapper.TeachMapper;
import cn.job.service.TeachService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service("teachService")
public class TeachServiceImpl implements TeachService {
    @Autowired
    private TeachMapper teachMapper;
    @Autowired
    private CompanyMapper companyMapper;
    @Override
    public int creTeach(Teach teach) {
        return teachMapper.insert(teach);
    }

    @Override
    public int updateTeach(Teach teach) {
        return teachMapper.updateById(teach);
    }

    @Override
    public int delTeach(Integer id) {
        return teachMapper.deleteById(id);
    }

    @Override
    public ArrayList<Teach> getTeaByComId(Integer comId) {
        return teachMapper.selectByComId(comId);
    }

    @Override
    public PageInfo<Teach> getJobsBykeys(int pageNum, int pageSize, String keys) {
        PageHelper.startPage(pageNum,pageSize);
        ArrayList<Teach> teaches=teachMapper.selectByKeys(keys);
        for(int i=0;i<teaches.size();i++){
            Teach teach=teaches.get(i);
            Integer comId=teach.getComid();
            Company company=companyMapper.selectById(comId);
            teach.setCompany(company);
        }
        PageInfo<Teach> pageInfo=new PageInfo<>(teaches);
        return  pageInfo;
    }
}
