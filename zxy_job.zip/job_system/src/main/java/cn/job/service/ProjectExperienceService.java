package cn.job.service;

import cn.job.entity.ProjectExperience;

import java.util.ArrayList;

/**
 * 项目/实践经验的业务层接口
 */
public interface ProjectExperienceService {
    /**
     * 添加项目经验
     * @param projectExperience
     * @return
     */
    int addProExp(ProjectExperience projectExperience);

    /**
     * 根据简历id查询项目经验
     * @param resId
     * @return
     */
    ProjectExperience getProExp(Integer resId);

    /**
     * 修改项目经验
     * @param projectExperience
     * @return
     */
    int editProExp(ProjectExperience projectExperience);

    /**
     * 删除项目经验
     * @param id
     * @return
     */
    int delProExp(Integer id);
}
