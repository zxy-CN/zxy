package cn.job.service;

import cn.job.entity.User;

/**
 *用户业务层接口
 */
public interface UserService {
    /**
     * 登录
     * @param uname
     * @param upwd
     * @return
     */
    User login(String uname,String upwd);

    /**
     * 注册学生用户
     * @param user
     * @return
     */
    int registerStu(User user);

    /**
     * 注册企业用户
     * @param user
     * @return
     */
    int registerCom(User user);

    /**
     * 修改密码
     * @param user
     * @return
     */
    int updatePwd(User user);
}
