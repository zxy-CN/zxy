package cn.job.service;

import cn.job.entity.Job;
import com.github.pagehelper.PageInfo;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * 职位的业务层接口
 */
public interface JobService {

    /**
     * 根据关键字模糊查询职位
     * @param keys
     * @return
     */
    PageInfo<Job> getJobsBykeys(int pageNum, int pageSize,String keys);

    /**
     * 添加一个职位
     * @param job
     * @return
     */
    int addJob(Job job);

    /**
     * 修改职位信息
     * @param job
     * @return
     */
    int updateJob(Job job);

    /**
     * 删除一个职位
     * @param id
     * @return
     */
    int delJob(Integer id);

    /**
     * 根据职位id查找职位
     * @param id
     * @return
     */
    Job getJobById(Integer id);

    /**
     * 根据公司id查询公司已经发布的职位
     * @param comId
     * @return
     */
    ArrayList<Job> getJobsBycomId(Integer comId);



}
