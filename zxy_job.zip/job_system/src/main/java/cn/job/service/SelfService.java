package cn.job.service;

import cn.job.entity.Self;
import org.omg.PortableInterceptor.INACTIVE;

/**
 * 自我评价的业务层接口
 */
public interface SelfService {
    /**
     * 添加自我评价
     * @param self
     * @return
     */
    int addSelf(Self self);

    /**
     * 根据简历id查询自我评价
     * @param resId
     * @return
     */
    Self getSelf(Integer resId);

    /**
     * 修改自我评价
     * @param self
     * @return
     */
    int editSelf(Self self);

    /**
     * 删除自我评价
     * @param id
     * @return
     */
    int delSelf(Integer id);
}
