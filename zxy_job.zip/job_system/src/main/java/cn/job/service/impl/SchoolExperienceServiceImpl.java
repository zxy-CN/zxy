package cn.job.service.impl;

import cn.job.entity.SchoolExperience;
import cn.job.mapper.SchoolExperienceMapper;
import cn.job.service.SchoolExperienceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service("schoolExperienceService")
public class SchoolExperienceServiceImpl implements SchoolExperienceService {
    @Autowired
    private SchoolExperienceMapper schoolExperienceMapper;
    @Override
    public int addSchExp(SchoolExperience schoolExperience) {
        return schoolExperienceMapper.insert(schoolExperience);
    }

    @Override
    public SchoolExperience getSchExps(Integer resId) {
        return schoolExperienceMapper.selectByResId(resId);
    }

    @Override
    public int editSchExp(SchoolExperience schoolExperience) {
        return schoolExperienceMapper.updateById(schoolExperience);
    }

    @Override
    public int delSchExp(Integer id) {
        return schoolExperienceMapper.deleteById(id);
    }
}
