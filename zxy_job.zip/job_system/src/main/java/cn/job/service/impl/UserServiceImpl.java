package cn.job.service.impl;
/**
 * 用户业务层接口的实现类
 */

import cn.job.entity.User;
import cn.job.mapper.UserMapper;
import cn.job.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("userService")
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;
    @Override
    public User login(String uname, String upwd) {
        return userMapper.selectUser(uname,upwd);
    }

    @Override
    public int registerStu(User user) {
        return userMapper.insertStu(user);
    }

    @Override
    public int registerCom(User user) {
        return userMapper.insertCom(user);
    }

    @Override
    public int updatePwd(User user) {
        return userMapper.updateById(user);
    }
}
