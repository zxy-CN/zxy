package cn.job.service.impl;

import cn.job.entity.EduExperience;
import cn.job.mapper.EduExperienceMapper;
import cn.job.service.EduExperienceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service("eduExperienceService")
public class EduExperienceServiceImpl implements EduExperienceService {
    @Autowired
    private EduExperienceMapper eduExperienceMapper;
    @Override
    public int addEdu(EduExperience eduExperience) {
        return eduExperienceMapper.insert(eduExperience);
    }

    @Override
    public EduExperience getEdus(Integer resId) {
        return eduExperienceMapper.selectByResId(resId);
    }

    @Override
    public int editEdu(EduExperience eduExperience) {
        return eduExperienceMapper.updateById(eduExperience);
    }

    @Override
    public int delEdu(Integer id) {
        return eduExperienceMapper.deleteById(id);
    }
}
