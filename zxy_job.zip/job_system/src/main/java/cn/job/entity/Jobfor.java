package cn.job.entity;

import java.io.Serializable;

public class Jobfor implements Serializable {
    private Integer id;

    private Integer resid;

    private String hopesalary;

    private String hopeplace;

    private String work;

    private String jobtype;

    private String worktime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getResid() {
        return resid;
    }

    public void setResid(Integer resid) {
        this.resid = resid;
    }

    public String getHopesalary() {
        return hopesalary;
    }

    public void setHopesalary(String hopesalary) {
        this.hopesalary = hopesalary == null ? null : hopesalary.trim();
    }

    public String getHopeplace() {
        return hopeplace;
    }

    public void setHopeplace(String hopeplace) {
        this.hopeplace = hopeplace == null ? null : hopeplace.trim();
    }

    public String getWork() {
        return work;
    }

    public void setWork(String work) {
        this.work = work == null ? null : work.trim();
    }

    public String getJobtype() {
        return jobtype;
    }

    public void setJobtype(String jobtype) {
        this.jobtype = jobtype == null ? null : jobtype.trim();
    }

    public String getWorktime() {
        return worktime;
    }

    public void setWorktime(String worktime) {
        this.worktime = worktime == null ? null : worktime.trim();
    }
}