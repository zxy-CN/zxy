package cn.job.entity;

import java.io.Serializable;
import java.util.Date;

public class Resume implements Serializable {
    private Integer id;

    private String resname;

    private Integer uid;

    private Date createtime;

    public Resume() {
    }

    public Resume(String resname, Integer uid) {
        this.resname = resname;
        this.uid = uid;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getResname() {
        return resname;
    }

    public void setResname(String resname) {
        this.resname = resname == null ? null : resname.trim();
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }
}