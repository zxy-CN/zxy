package cn.job.entity;

import java.io.Serializable;
import java.util.Date;

public class Job implements Serializable {
    private Integer id;

    private String jobname;

    private String jobsalary;

    private String jobplace;

    private String jobrequire;

    private String degreerequire;

    private String jobtype;

    private String keywords;

    private String jobdetail;

    private Date createtime;

    private Integer comid;

    private Integer delmark;

    private Company company;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getJobname() {
        return jobname;
    }

    public void setJobname(String jobname) {
        this.jobname = jobname == null ? null : jobname.trim();
    }

    public String getJobsalary() {
        return jobsalary;
    }

    public void setJobsalary(String jobsalary) {
        this.jobsalary = jobsalary == null ? null : jobsalary.trim();
    }

    public String getJobplace() {
        return jobplace;
    }

    public void setJobplace(String jobplace) {
        this.jobplace = jobplace == null ? null : jobplace.trim();
    }

    public String getJobrequire() {
        return jobrequire;
    }

    public void setJobrequire(String jobrequire) {
        this.jobrequire = jobrequire == null ? null : jobrequire.trim();
    }

    public String getDegreerequire() {
        return degreerequire;
    }

    public void setDegreerequire(String degreerequire) {
        this.degreerequire = degreerequire == null ? null : degreerequire.trim();
    }

    public String getJobtype() {
        return jobtype;
    }

    public void setJobtype(String jobtype) {
        this.jobtype = jobtype == null ? null : jobtype.trim();
    }

    public String getKeyWords() {
        return keywords;
    }

    public void setKeyWords(String keywords) {
        this.keywords = keywords == null ? null : keywords.trim();
    }

    public String getJobdetail() {
        return jobdetail;
    }

    public void setJobdetail(String jobdetail) {
        this.jobdetail = jobdetail == null ? null : jobdetail.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Integer getComid() {
        return comid;
    }

    public void setComid(Integer comid) {
        this.comid = comid;
    }

    public Integer getDelmark() {
        return delmark;
    }

    public void setDelmark(Integer delmark) {
        this.delmark = delmark;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }
}