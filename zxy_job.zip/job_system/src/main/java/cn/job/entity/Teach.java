package cn.job.entity;

import java.io.Serializable;
import java.util.Date;

public class Teach implements Serializable {
    private Integer id;

    private String teachname;

    private Date teachtime;

    private String place;

    private Integer comid;

    private Company company;

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTeachname() {
        return teachname;
    }

    public void setTeachname(String teachname) {
        this.teachname = teachname == null ? null : teachname.trim();
    }

    public Date getTeachtime() {
        return teachtime;
    }

    public void setTeachtime(Date teachtime) {
        this.teachtime = teachtime;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place == null ? null : place.trim();
    }

    public Integer getComid() {
        return comid;
    }

    public void setComid(Integer comid) {
        this.comid = comid;
    }
}