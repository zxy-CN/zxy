package cn.job.entity;

import java.io.Serializable;

public class Company implements Serializable {
    private Integer id;

    private Integer uid;

    private String comname;

    private String comsize;

    private String comaddress;

    private String comlevel;

    private String comdetail;

    private String comtype;

    private Integer compass;

    public Integer getCompass() {
        return compass;
    }

    public void setCompass(Integer compass) {
        this.compass = compass;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getComname() {
        return comname;
    }

    public void setComname(String comname) {
        this.comname = comname == null ? null : comname.trim();
    }

    public String getComsize() {
        return comsize;
    }

    public void setComsize(String comsize) {
        this.comsize = comsize == null ? null : comsize.trim();
    }

    public String getComaddress() {
        return comaddress;
    }

    public void setComaddress(String comaddress) {
        this.comaddress = comaddress == null ? null : comaddress.trim();
    }

    public String getComlevel() {
        return comlevel;
    }

    public void setComlevel(String comlevel) {
        this.comlevel = comlevel == null ? null : comlevel.trim();
    }

    public String getComdetail() {
        return comdetail;
    }

    public void setComdetail(String comdetail) {
        this.comdetail = comdetail == null ? null : comdetail.trim();
    }

    public String getComtype() {
        return comtype;
    }

    public void setComtype(String comtype) {
        this.comtype = comtype == null ? null : comtype.trim();
    }
}