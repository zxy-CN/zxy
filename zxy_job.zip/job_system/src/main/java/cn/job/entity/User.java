package cn.job.entity;

import java.io.Serializable;
import java.util.Date;

public class User implements Serializable {
    private Integer id;

    private String uname;

    private String upwd;

    private String utype;

    private Integer dmark;

    private Date createtime;

    public User() {

    }

    public User(String uname, String upwd, String utype, Integer dmark) {
        this.uname = uname;
        this.upwd = upwd;
        this.utype = utype;
        this.dmark = dmark;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname == null ? null : uname.trim();
    }

    public String getUpwd() {
        return upwd;
    }

    public void setUpwd(String upwd) {
        this.upwd = upwd == null ? null : upwd.trim();
    }

    public String getUtype() {
        return utype;
    }

    public void setUtype(String utype) {
        this.utype = utype == null ? null : utype.trim();
    }

    public Integer getDmark() {
        return dmark;
    }

    public void setDmark(Integer dmark) {
        this.dmark = dmark;
    }
}