var demo=new Vue({
    el:'#mana_vue',
    data:{
        user:"",
        send:{
            jobid:"",
            state:"已投递"
        },
        sends:{}
    },
    methods:{
        c1:function () {
            $(".company_center_aside dd").removeClass("current");
            $("#res_c1").addClass("current");
            $(".content dl").addClass("dn");
            $("#res1").removeClass("dn");
            $("#tip1").addClass("dn");
            demo.$data.send.state="已投递";
            $.ajax({
                url: "http://localhost:8088/get/sends/com",
                type: 'POST',
                data:JSON.stringify(demo.$data.send),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        demo.$data.sends=dt.data;
                    }else{
                        $("#res1 form").addClass("dn");
                        $("#tip1").removeClass("dn");
                    }
                }
            })
        },
        c2:function () {
            $(".company_center_aside dd").removeClass("current");
            $("#res_c2").addClass("current");
            $(".content dl").addClass("dn");
            $("#res2").removeClass("dn");
            $("#tip2").addClass("dn");
            demo.$data.send.state="感兴趣";
            $.ajax({
                url: "http://localhost:8088/get/sends/com",
                type: 'POST',
                data:JSON.stringify(demo.$data.send),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        demo.$data.sends=dt.data;
                    }else{
                        $("#res2 form").addClass("dn");
                        $("#tip2").removeClass("dn");
                    }
                }
            })
        },
        c3:function () {
            $(".company_center_aside dd").removeClass("current");
            $("#res_c3").addClass("current");
            $(".content dl").addClass("dn");
            $("#res3").removeClass("dn");
            $("#tip3").addClass("dn");
            demo.$data.send.state="通知面试";
            $.ajax({
                url: "http://localhost:8088/get/sends/com",
                type: 'POST',
                data:JSON.stringify(demo.$data.send),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        demo.$data.sends=dt.data;
                    }else{
                        $("#res3 form").addClass("dn");
                        $("#tip3").removeClass("dn");
                    }
                }
            })
        },
        c4:function () {
            $(".company_center_aside dd").removeClass("current");
            $("#res_c4").addClass("current");
            $(".content dl").addClass("dn");
            $("#res4").removeClass("dn");
            $("#tip4").addClass("dn");
            demo.$data.send.state="不合适";
            $.ajax({
                url: "http://localhost:8088/get/sends/com",
                type: 'POST',
                data:JSON.stringify(demo.$data.send),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        demo.$data.sends=dt.data;
                    }else{
                        $("#res4 form").addClass("dn");
                        $("#tip4").removeClass("dn");
                    }
                }
            })
        },
        c5:function () {
            $(".company_center_aside dd").removeClass("current");
            $("#res_c5").addClass("current");
            $(".content dl").addClass("dn");
            $("#res5").removeClass("dn");
            $("#tip5").addClass("dn");
            demo.$data.send.state="已查看";
            $.ajax({
                url: "http://localhost:8088/get/sends/com",
                type: 'POST',
                data:JSON.stringify(demo.$data.send),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        demo.$data.sends=dt.data;
                    }else{
                        $("#res5 form").addClass("dn");
                        $("#tip5").removeClass("dn");
                    }
                }
            })
        },
        see:function (s) {
            $.ajax({
                url: "http://localhost:8088/send/see",
                type: 'POST',
                data:JSON.stringify(s),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        alert("投递状态修改成功");
                        location.reload();
                    }else{
                        alert("err");
                    }
                }
            })
        },
        like:function (s) {
            $.ajax({
                url: "http://localhost:8088/send/want",
                type: 'POST',
                data:JSON.stringify(s),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        alert("投递状态修改成功");
                        location.reload();
                    }else{
                        alert("err");
                    }
                }
            })
        },
        not:function (s) {
            $.ajax({
                url: "http://localhost:8088/send/get",
                type: 'POST',
                data:JSON.stringify(s),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        alert("投递状态修改成功");
                        location.reload();
                    }else{
                        alert("err");
                    }
                }
            })
        },
        no:function (s) {
            $.ajax({
                url: "http://localhost:8088/send/not",
                type: 'POST',
                data:JSON.stringify(s),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        alert("投递状态修改成功");
                        location.reload();
                    }else{
                        alert("err");
                    }
                }
            })
        },
        tojianli:function (s) {
            window.open("preview.html?id="+s.resume.id,"_blank");
        }
    },
    computed: {

    }
})
$(function(){
    //取session
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo.$data.user=dt.data;
            }else {
                window.location.href="login.html";
            }
        })
    urlinfo=window.location.href;  //获取当前页面的url
    len=urlinfo.length;//获取url的长度
    offset=urlinfo.indexOf("?");//设置参数字符串开始的位置
    newsidinfo=urlinfo.substr(offset,len)//取出参数字符串
    newsids=newsidinfo.split("=");//对获得的参数字符串按照“=”进行分割
    newsid=decodeURIComponent(newsids[1]);//得到参数值

    demo.$data.send.jobid=newsid;

    $.ajax({
        url: "http://localhost:8088/get/sends/com",
        type: 'POST',
        data:JSON.stringify(demo.$data.send),
        contentType:"application/json;charset=utf-8",
        success: function(dt){
            if(dt.status=="ok"){
                demo.$data.sends=dt.data;
            }else{
                $("#res1 form").addClass("dn");
                $("#tip1").removeClass("dn");
            }
        }
    })

    $("#fk").mouseenter(function () {
        $("#list dd").css("display","block");
    }),
        $("#fk").mouseleave(function () {
            $("#list dd").css("display","none");
        })


});

