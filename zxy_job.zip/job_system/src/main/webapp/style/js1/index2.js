var demo=new Vue({
    el:'#index2_vue',
    data:{
        user:"",
        com:{
            uid:""
        }
    },
    methods:{
        save:function () {
            demo.$data.com.uid=demo.$data.user.id;
            $.ajax({
                url: "http://localhost:8088/add/cominf",
                type: 'POST',
                data:JSON.stringify(demo.$data.com),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        alert("企业信息提交成功")
                        $("#cominf_ed").addClass("dn");
                        $("#cominf_show").removeClass("dn");
                    }else{
                        alert("err");
                    }
                }
            })
        }
    },
    computed: {

    }
})
$(function(){
    //取session
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo.$data.user=dt.data;
                getCom();
            }else {
                window.location.href="login.html";
            }
        })
    function getCom(){
        $.getJSON("http://localhost:8088/get/cominf",
            {
                "uid":demo.$data.user.id
            },
            function (dt) {
                if (dt.status=="ok") {
                    demo.$data.com=dt.data;
                    $("#cominf_ed").addClass("dn");
                    $("#cominf_show").removeClass("dn");
                }
            })
    }
    $("#comed").click(function () {
        $("#cominf_ed").removeClass("dn");
        $("#cominf_show").addClass("dn");
    })

});

