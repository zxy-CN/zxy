var demo = new Vue({
    el: '#register_vue',
    data: {
        uname:"",
        upwd:""
    },
    methods: {
        reg:function () {
            var _self=this;
            if($("input:radio:checked").val()!=undefined && _self.uname!="" && _self.upwd!="") {
                if ($("input:radio:checked").val()==0){
                    $.getJSON("http://localhost:8088//reg/stu",
                        {"uname":_self.uname,
                            "upwd":_self.upwd},
                        function (dt) {
                            if (dt.status=="ok"){
                                alert("学生注册成功");
                                window.location.replace("login.html");
                            }else {
                                alert("注册失败");
                            }
                        })
                }else if ($("input:radio:checked").val()==1) {
                    $.getJSON("http://localhost:8088//reg/com",
                        {"uname":_self.uname,
                            "upwd":_self.upwd},
                        function (dt) {
                            if (dt.status=="ok"){
                                alert("企业注册成功");
                                window.location.replace("login.html");
                            }else {
                                alert("注册失败");
                            }
                        })
                }
            }else {
                if ($("input:radio:checked").val()==undefined) {
                    $("#beError1").css("display","block");
                    $("#beError1").text("请选择注册身份");
                }
                if (_self.uname==""){
                    $("#beError2").css("display","block");
                    $("#beError2").text("请输入用户名");
                }
                if (_self.upwd==""){
                    $("#beError3").css("display","block");
                    $("#beError3").text("请输入密码");
                }
            }

        }
    },
    computed: {}
});
$(function () {
    var unameReg = /^[a-zA-Z]([-_a-zA-Z0-9]{5,19})+$/;
    var upwdReg=/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;
    $('.register_radio li input').click(function(e){
        $("#beError1").css("display","none");
        $(this).parent('li').addClass('current').append('<em></em>').siblings().removeClass('current').find('em').remove();
    });
    $("#email").blur(function () {
        if ($(this).val()!="" && unameReg.test($(this).val())) {
            $("#beError2").css("display","none");
        }else {
            $("#beError2").css("display","block");
            $("#beError2").text("请输入由字母开头，长度5-19的用户名");
        }
    })
    $("#password").blur(function () {
        if ($(this).val()!="" && upwdReg.test($(this).val())) {
            $("#beError3").css("display","none");
        }else {
            $("#beError3").css("display","block");
            $("#beError3").text("请输入至少8个字符，至少1个大写字母，1个小写字母和1个数字的密码");
        }
    })
})