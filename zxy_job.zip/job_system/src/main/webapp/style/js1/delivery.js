var demo=new Vue({
    el:'#delivery_vue',
    data:{
        user:"",
        send:{
            resid:""
        },
        sends:""
    },
    methods:{
        sel:function (n) {
            Vue.delete(this.send,'state');
            if (n=='all'){
                $.ajax({
                    url: "http://localhost:8088/get/sends",
                    type: 'POST',
                    data:JSON.stringify(demo.$data.send),
                    contentType:"application/json;charset=utf-8",
                    success: function(dt){
                        if(dt.status=="ok"){
                            demo.$data.sends=dt.data;
                        }else{
                            alert("err");
                        }
                    }
                })
            }else {
                demo.$data.send.state=n;
                $.ajax({
                    url: "http://localhost:8088/get/sends",
                    type: 'POST',
                    data:JSON.stringify(demo.$data.send),
                    contentType:"application/json;charset=utf-8",
                    success: function(dt){
                        if(dt.status=="ok"){
                            demo.$data.sends=dt.data;
                        }else{
                            alert("err");
                        }
                    }
                })
            }
        }
    },
    computed: {

    }
})
$(function(){
    //取session
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo.$data.user=dt.data;
                getReg();
            }else {
                $("#list").addClass("dn");
                $(".collapsible_menu").append("<dt><a href='login.html' style='color: white'>登录/注册</a></dt>")
            }
        })
    //取简历信息
    function getReg() {
        $.getJSON("http://localhost:8088/get/res",
            {"uid":demo.$data.user.id},
            function (dt) {
                if (dt.status=="ok") {
                    demo.$data.send.resid=dt.data.id;
                    getSend();
                }
            })
    }
    function getSend(){
        $.ajax({
            url: "http://localhost:8088/get/sends",
            type: 'POST',
            data:JSON.stringify(demo.$data.send),
            contentType:"application/json;charset=utf-8",
            success: function(dt){
                if(dt.status=="ok"){
                    demo.$data.sends=dt.data;
                }else{
                    alert("没有投递");
                }
            }
        })
    }
    $(".delivery_tabs li").click(function () {
        $(".delivery_tabs li").removeClass("current");
        $(this).addClass("current");
    })
});

