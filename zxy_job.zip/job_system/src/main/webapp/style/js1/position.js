var demo=new Vue({
    el:'#positions_vue',
    data:{
        user:"",
        com:"",
        job:""
    },
    methods:{
        edit:function (id) {
            window.open("create.html?id="+id);
        },
        mana:function (id) {
            window.open("resmanager.html?id="+id);
        }
    },
    computed: {

    }
})
$(function(){
    //取session
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo.$data.user=dt.data;
                getCom();
            }else {
                window.location.href="login.html";
            }
        })
    function getCom(){
        $.getJSON("http://localhost:8088/get/cominf",
            {
                "uid":demo.$data.user.id
            },
            function (dt) {
                if (dt.status=="ok") {
                    demo.$data.com=dt.data
                    geJob();
                }else {
                    alert("请完善公司信息");
                    window.location.href="index2.html";
                }
            })
    }
    function geJob() {
        $.getJSON("http://localhost:8088/get/jobs",
            {
                "comId":demo.$data.com.id
            },
            function (dt) {
                if (dt.status=="ok") {
                    demo.$data.job=dt.data
                }else {
                   $("#tip_no").removeClass("dn");
                }
            })
    }


});

