var demo=new Vue({
    el:'#preview_vue',
    data:{
        res:"",
        stu:{
            borndate: "",
            degree: "",
            email: "",
            idcard: "",
            liveplace: "",
            majorname: "",
            phone: "",
            realname: "",
            schoolName: "",
            sex: "",
            uid: ""
        },
        jobfor:{
            hopeplace:"",
            jobtype:"",
            work:"",
            hopesalary:"",
            worktime:"",
            resid:""
        },
        schexp:{
            begin:"",
            end:"",
            detail:"",
            name:"",
            resid:""
        },
        proexp:{
            resid:"",
            name:"",
            begin:"",
            end:"",
            play:"",
            detail:""
        },
        eduexp:{
            resid:"",
            schoolname:"",
            majorname:"",
            degree:"",
            begin:"",
            end:"",
            detail:""
        },
        skill:{
            resid:"",
            detail:""
        },
        self:{
            resid:"",
            detail:""
        }
    },
    methods:{

    },
    computed: {

    }
})
$(function(){

    urlinfo=window.location.href;  //获取当前页面的url
    len=urlinfo.length;//获取url的长度
    offset=urlinfo.indexOf("?");//设置参数字符串开始的位置
    newsidinfo=urlinfo.substr(offset,len)//取出参数字符串
    newsids=newsidinfo.split("=");//对获得的参数字符串按照“=”进行分割
    newsid=decodeURIComponent(newsids[1]);//得到参数值
    //取简历信息
    $.getJSON("http://localhost:8088/get/byid",
        {"id":newsid},
        function (dt) {
            if (dt.status=="ok") {
                demo.$data.res=dt.data;
                getRegDetail();
            }else {
                alert("无简历信息")
            }
        })
    //取简历细节
    function getRegDetail() {
        var _self=this;
        $.ajax({
            url: "http://localhost:8088/get/res/detail",
            type: 'POST',
            data:JSON.stringify(demo.$data.res),
            contentType:"application/json;charset=utf-8",
            success: function(dt){
                if(dt.status=="ok"){
                    //判断取到的求职意向
                    if (dt.data.jobfor!=null){
                        demo.$data.jobfor=dt.data.jobfor;
                    }else {
                        $("#2pr").addClass("dn");
                        $("#pr2").removeClass("dn");
                    }
                    //判断取到的个人信息
                    if (dt.data.stuinf!=null){
                        demo.$data.stu=dt.data.stuinf;
                    } else {
                        $("#1pr").addClass("dn");
                        $("#pr1").removeClass("dn");
                    }
                    //判断校园经历
                    if (dt.data.schexp!=null){
                        demo.$data.schexp=dt.data.schexp;;
                    } else {
                        $("#4pr").addClass("dn");
                        $("#pr4").removeClass("dn");
                    }
                    //判断项目经验
                    if (dt.data.proexp!=null){
                        demo.$data.proexp=dt.data.proexp;
                    } else {
                        $("#5pr").addClass("dn");
                        $("#pr5").removeClass("dn");
                    }
                    //判断教育经历
                    if (dt.data.eduexp!=null){
                        demo.$data.eduexp=dt.data.eduexp;
                    } else {
                        $("#3pr").addClass("dn");
                        $("#pr3").removeClass("dn");
                    }
                    //判断专业技能
                    if (dt.data.skill!=null){
                        demo.$data.skill=dt.data.skill;
                    } else {
                        $("#6pr").addClass("dn");
                        $("#pr6").removeClass("dn");
                    }
                    //判断自我评价
                    if (dt.data.self!=null){
                        demo.$data.self=dt.data.self;
                    } else {
                        $("#7pr").addClass("dn");
                        $("#pr7").removeClass("dn");
                    }
                }else{
                    alert("err");
                }
            }
        })
    }
});

