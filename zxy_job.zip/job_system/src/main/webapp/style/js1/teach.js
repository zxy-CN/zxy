var demo=new Vue({
    el:'#tea_vue',
    data:{
        user:"",
        tea:{
            teachname:"",
            teachtime:"",
            place:"",
            comid:""
        },
        teas:{},
        com:""
    },
    methods:{
        cretea:function () {
            $(".company_center_aside dd").removeClass("current");
            $("#res_c1").addClass("current");
            $(".content dl").addClass("dn");
            $("#res1").removeClass("dn");
        },
        seetea:function () {
            $(".company_center_aside dd").removeClass("current");
            $("#res_c5").addClass("current");
            $(".content dl").addClass("dn");
            $("#res5").removeClass("dn");
        },
        cre_save:function () {
            demo.$data.tea.comid=demo.$data.com.id;
            $.ajax({
                url: "http://localhost:8088/add/tea",
                type: 'POST',
                data:JSON.stringify(demo.$data.tea),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        alert("发布成功");
                        window.location.href="teach.html"
                    }else{
                        alert("err");
                    }
                }
            })
        },
        edit:function (t) {
            demo.$data.tea=t;
            $(".content dl").addClass("dn");
            $("#res2").removeClass("dn");
        },
        edit_save:function () {
            $.ajax({
                url: "http://localhost:8088/edit/tea",
                type: 'POST',
                data:JSON.stringify(demo.$data.tea),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        alert("修改成功");
                        window.location.href="teach.html"
                    }else{
                        alert("err");
                    }
                }
            })
        },
        edit_cancel:function () {
            $(".content dl").addClass("dn");
            $("#res5").removeClass("dn");
        },
        del:function (t) {
            $.getJSON("http://localhost:8088/del/tea",
                {
                    "id":t.id
                },
                function (dt) {
                    if (dt.status=="ok") {
                        alert("删除成功！");
                        window.location.href="teach.html";
                    }else {
                        alert("err");
                    }
                })
        }

    },
    computed: {

    }
})
$(function(){
    //取session
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo.$data.user=dt.data;
                getCom();
            }else {
                window.location.href="login.html";
            }
        })
    function getCom(){
        $.getJSON("http://localhost:8088/get/cominf",
            {
                "uid":demo.$data.user.id
            },
            function (dt) {
                if (dt.status=="ok") {
                    demo.$data.com=dt.data;
                    getTea();
                }else {
                    alert("请完善公司信息再发布工作");
                    window.location.href="index2.html";
                }
            })
    }
    function getTea(){
        $.getJSON("http://localhost:8088/get/teas",
            {
                "comid":demo.$data.com.id
            },
            function (dt) {
                if (dt.status=="ok") {
                    demo.$data.teas=dt.data;
                }else {
                   $("#tip5").removeClass("dn");
                   $("#res5 form").addClass("dn")
                }
            })
    }


    $("#fk").mouseenter(function () {
        $("#list dd").css("display","block");
    }),
        $("#fk").mouseleave(function () {
            $("#list dd").css("display","none");
        })


});

