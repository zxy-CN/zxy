var demo=new Vue({
    el:'#list_vue',
    data:{
        keys:"",
        job:"",
        user:"",
        navigatepageNums:""
    },
    methods:{
        sel:function () {
            var _self=this;
            $.getJSON("http://localhost:8088/get/jobs/key",
                {   "pageNum":1,
                    "keys":_self.keys
                },
                function (dt) {
                    if (dt.status=="ok"){
                        if (Object.keys(dt.data.list).length!=0){
                            $("#tip_msg").css("display","none");
                            demo.$data.job=dt.data.list;
                            _self.navigatepageNums=dt.data.navigatepageNums;
                            $(".Pagination").css("display","block");
                        }else {
                            demo.$data.job=null;
                            $(".Pagination").css("display","none");
                            $("#tip_msg").css("display","block");
                        }
                    }else{
                        alert("没有数据");
                    }}
            )
        },
        see:function (j) {
            window.open("jobdetail.html?resid="+j.id,"_blank");
        },
        sea:function (job) {
            var _self=this;
            _self.keys=job;
            $.getJSON("http://localhost:8088/get/jobs/key",
                {   "pageNum":1,
                    "keys":_self.keys
                },
                function (dt) {
                    if (dt.status=="ok"){
                        if (Object.keys(dt.data.list).length!=0){
                            $("#tip_msg").css("display","none");
                            demo.$data.job=dt.data.list;
                            _self.navigatepageNums=dt.data.navigatepageNums;
                            $(".Pagination").css("display","block");
                        }else {
                            demo.$data.job=null;
                            $(".Pagination").css("display","none");
                            $("#tip_msg").css("display","block");
                        }
                    }else{
                        alert("没有数据");
                    }}
            )
        },
        page:function (n) {
            var _self=this;
            $.getJSON("http://localhost:8088/get/jobs/key",
                {   "pageNum":n,
                    "keys":_self.keys
                },
                function (dt) {
                    if (dt.status=="ok"){
                        if (Object.keys(dt.data.list).length!=0){
                            $("#tip_msg").css("display","none");
                            demo.$data.job=dt.data.list;
                            _self.navigatepageNums=dt.data.navigatepageNums;
                        }else {
                            $("#tip_msg").css("display","block");
                        }
                    }else{
                        alert("没有数据");
                    }}
            )
        },

    },
    computed: {

    }
});
$(function () {

    urlinfo=window.location.href;  //获取当前页面的url
    len=urlinfo.length;//获取url的长度
    offset=urlinfo.indexOf("?");//设置参数字符串开始的位置
    newsidinfo=urlinfo.substr(offset,len)//取出参数字符串
    newsids=newsidinfo.split("=");//对获得的参数字符串按照“=”进行分割
    newsid=decodeURIComponent(newsids[1]);//得到参数值

    demo.$data.keys=newsid;
    $.getJSON("http://localhost:8088/get/jobs/key",
        {   "pageNum":1,
            "keys":newsid
        },
        function (dt) {
            if (dt.status=="ok"){
                if (Object.keys(dt.data.list).length!=0){
                    $("#tip_msg").css("display","none");
                    demo.$data.job=dt.data.list;
                    demo.$data.navigatepageNums=dt.data.navigatepageNums;
                }else {
                    $("#tip_msg").css("display","block");
                }
            }else{
                alert("没有数据");
            }}
    )
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo.$data.user=dt.data;
            }else {
                $("#list").addClass("dn");
                $(".collapsible_menu").append("<dt><a href='login.html' style='color: white'>登录/注册</a></dt>")
            }
        })
    $(".collapsible_menu").mouseenter(function () {
        $("#list dd").css("display","block");
    })
    $(".collapsible_menu").mouseleave(function () {
        $("#list dd").css("display","none");
    })
})
