var demo=new Vue({
    el:'#upd_vue',
    data:{
        user:"",
        npwd:"",
        cpwd:""
    },
    methods:{
        save:function () {
            demo.$data.user.upwd=demo.$data.npwd;
            $.ajax({
                url: "http://localhost:8088/upwd",
                type: 'POST',
                data:JSON.stringify(demo.$data.user),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        alert("修改成功");
                    }else{
                        alert("err");
                    }
                }
            })
        }

    },
    computed: {

    }
});
$(function () {
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo.$data.user=dt.data;
            }else {
                window.location.href="login.html";
            }
        })
    $("#cpwd").blur(function () {
        if (demo.$data.npwd!=demo.$data.cpwd){
            $("#err_tip").removeClass("dn")
            $("#save").addClass("dn")
        }else {
            $("#err_tip").addClass("dn");
            $("#save").removeClass("dn")
        }
    })

})
