var demo=new Vue({
    el:'#index_vue',
    data:{
        user:"",
        job:"",
        job1:"",
        keys:""
    },
    methods:{
        //搜索时跳到搜索页，附带参数
        sel:function () {
            window.location.href="list1.html?keys="+this.keys;
        }

    },
    computed: {

    }
})
$(function(){
    //取热门职位的数据（这里简化取“开发”关键词职位填充）
    $.getJSON("http://localhost:8088/get/jobs/key",
        {   "pageNum":1,
            "keys":"开发"
        },
        function (dt) {
            if (dt.status=="ok"){
                if (Object.keys(dt.data.list).length!=0){
                    demo.$data.job=dt.data.list;
                }else {
                }
            }else{
                alert("没有数据");
            }}
    )
    //取热门职位的数据（这里简化取“php”关键词职位填充）
    $.getJSON("http://localhost:8088/get/jobs/key",
        {   "pageNum":1,
            "keys":"php"
        },
        function (dt) {
            if (dt.status=="ok"){
                if (Object.keys(dt.data.list).length!=0){
                    demo.$data.job1=dt.data.list;
                }else {
                }
            }else{
                alert("没有数据");
            }}
    )
    //取session
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo.$data.user=dt.data;
            }else {
                $("#list").addClass("dn");
                $(".collapsible_menu").append("<dt><a href='login.html' style='color: white'>登录/注册</a></dt>")
            }
        }),
        $("#h1").click(function () {
            $(this).addClass("current");
            $("#h2").removeClass("current");
            $("#h3").removeClass("dn");
            $("#h4").addClass("dn");
        })
    $("#h2").click(function () {
        $(this).addClass("current");
        $("#h1").removeClass("current");
        $("#h4").removeClass("dn");
        $("#h3").addClass("dn");
    })
});

