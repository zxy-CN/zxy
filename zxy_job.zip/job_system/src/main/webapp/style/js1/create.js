var demo=new Vue({
    el:'#create_vue',
    data:{
        user:"",
        job:{
            comid:""
        }
    },
    methods:{
        save:function () {
            $.ajax({
                url: "http://localhost:8088/add/job",
                type: 'POST',
                data:JSON.stringify(demo.$data.job),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        alert("发布成功");
                        window.location.href="positions.html"
                    }else{
                        alert("err");
                    }
                }
            })
        },
        save1:function () {
            $.ajax({
                url: "http://localhost:8088/update/job",
                type: 'POST',
                data:JSON.stringify(demo.$data.job),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        alert("修改成功");
                        window.location.href="positions.html"
                    }else{
                        alert("err");
                    }
                }
            })
        }
    },
    computed: {

    }
})
$(function(){
    //取session
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo.$data.user=dt.data;
                getCom();
            }else {
                window.location.href="login.html";
            }
        })
    function getCom(){
        $.getJSON("http://localhost:8088/get/cominf",
            {
                "uid":demo.$data.user.id
            },
            function (dt) {
                if (dt.status=="ok") {
                    demo.$data.job.comid=dt.data.id;
                }else {
                    alert("请完善公司信息再发布工作");
                    window.location.href="index2.html";
                }
            })
    }

    urlinfo=window.location.href;  //获取当前页面的url
    len=urlinfo.length;//获取url的长度
    offset=urlinfo.indexOf("?");//设置参数字符串开始的位置
    newsidinfo=urlinfo.substr(offset,len)//取出参数字符串
    newsids=newsidinfo.split("=");//对获得的参数字符串按照“=”进行分割
    newsid=decodeURIComponent(newsids[1]);//得到参数值

    if (newsid==='undefined'){

    }else {
        $("#tip_job").text("修改职位信息");
        $("#button1").addClass("dn");
        $("#button2").removeClass("dn");
        $.getJSON("http://localhost:8088/get/job",
            {
                "id":newsid
            },
            function (dt) {
                if (dt.status=="ok") {
                    demo.$data.job=dt.data;
                }
            })
    }


});

