var demo = new Vue({
    el: '#login_vue',
    data: {
        uname:"",
        upwd:""
    },
    methods: {
        login:function () {
            var _self=this;
            $.getJSON("http://localhost:8088/login",
                {"uname":_self.uname,
                    "upwd":_self.upwd},
                function (dt) {
                    if (dt.status=="ok"){
                        if (dt.data.utype=="学生") {
                            window.location.href="index1.html";
                        }if(dt.data.utype=="企业"){
                            window.location.href="index2.html";
                        }
                    }else {
                        alert("登录失败");
                    }
                })
        }
    },
    computed: {}
});
$(function () {
    $.getJSON("http://localhost:8088/clear")
})