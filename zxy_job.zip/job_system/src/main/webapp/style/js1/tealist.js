var demo=new Vue({
    el:'#tealist_vue',
    data:{
        keys:"",
        tea:"",
        user:"",
        navigatepageNums:""
    },
    methods:{
        sel:function () {
            var _self=this;
            $.getJSON("http://localhost:8088/get/tea/key",
                {   "pageNum":1,
                    "keys":_self.keys
                },
                function (dt) {
                    if (dt.status=="ok"){
                        if (Object.keys(dt.data.list).length!=0){
                            $("#tip_msg").css("display","none");
                            demo.$data.tea=dt.data.list;
                            _self.navigatepageNums=dt.data.navigatepageNums;
                            $(".Pagination").css("display","block");
                        }else {
                            demo.$data.tea=null;
                            $(".Pagination").css("display","none");
                            $("#tip_msg").css("display","block");
                        }
                    }else{
                        alert("没有数据");
                    }}
            )
        },
        sea:function (tea) {
            var _self=this;
            _self.keys=tea;
            $.getJSON("http://localhost:8088/get/tea/key",
                {   "pageNum":1,
                    "keys":_self.keys
                },
                function (dt) {
                    if (dt.status=="ok"){
                        if (Object.keys(dt.data.list).length!=0){
                            $("#tip_msg").css("display","none");
                            demo.$data.tea=dt.data.list;
                            _self.navigatepageNums=dt.data.navigatepageNums;
                            $(".Pagination").css("display","block");
                        }else {
                            demo.$data.tea=null;
                            $(".Pagination").css("display","none");
                            $("#tip_msg").css("display","block");
                        }
                    }else{
                        alert("没有数据");
                    }}
            )
        },
        page:function (n) {
            var _self=this;
            $.getJSON("http://localhost:8088/get/tea/key",
                {   "pageNum":n,
                    "keys":_self.keys
                },
                function (dt) {
                    if (dt.status=="ok"){
                        if (Object.keys(dt.data.list).length!=0){
                            $("#tip_msg").css("display","none");
                            demo.$data.tea=dt.data.list;
                            _self.navigatepageNums=dt.data.navigatepageNums;
                        }else {
                            $("#tip_msg").css("display","block");
                        }
                    }else{
                        alert("没有数据");
                    }}
            )
        },

    },
    computed: {

    }
});
$(function () {

    $.getJSON("http://localhost:8088/get/tea/key",
        {   "pageNum":1,
            "keys":""
        },
        function (dt) {
            if (dt.status=="ok"){
                if (Object.keys(dt.data.list).length!=0){
                    $("#tip_msg").css("display","none");
                    demo.$data.tea=dt.data.list;
                    demo.$data.navigatepageNums=dt.data.navigatepageNums;
                }else {
                    $("#tip_msg").css("display","block");
                }
            }else{
                alert("没有数据");
            }}
    )
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo.$data.user=dt.data;
            }else {
                $("#list").addClass("dn");
                $(".collapsible_menu").append("<dt><a href='login.html' style='color: white'>登录/注册</a></dt>")
            }
        })
    $(".collapsible_menu").mouseenter(function () {
        $("#list dd").css("display","block");
    })
    $(".collapsible_menu").mouseleave(function () {
        $("#list dd").css("display","none");
    })
})
