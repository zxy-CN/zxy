var demo=new Vue({
    el:'#res_vue',
    data:{
        user:"",
        res:"",
        stu:{
            borndate: "",
            degree: "",
            email: "",
            idcard: "",
            liveplace: "",
            majorname: "",
            phone: "",
            realname: "",
            schoolName: "",
            sex: "",
            uid: ""
        },
        jobfor:{
            hopeplace:"",
            jobtype:"",
            work:"",
            hopesalary:"",
            worktime:"",
            resid:""
        },
        schexp:{
            begin:"",
            end:"",
            detail:"",
            name:"",
            resid:""
        },
        proexp:{
            resid:"",
            name:"",
            begin:"",
            end:"",
            play:"",
            detail:""
        },
        eduexp:{
            resid:"",
            schoolname:"",
            majorname:"",
            degree:"",
            begin:"",
            end:"",
            detail:""
        },
        skill:{
            resid:"",
            detail:""
        },
        self:{
            resid:"",
            detail:""
        }
    },
    methods:{
        //搜索时跳到搜索页，附带参数
        saveRegName:function () {
            $.ajax({
                url: "http://localhost:8088/edit/res",
                type: 'POST',
                data:JSON.stringify(demo.$data.res),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        $("#resumeNameForm").addClass("dn");
                        $(".nameShow").removeClass("dn");
                    }else{
                        alert("err");
                    }
                }
            })
        },
        //添加或修改个人信息
        savaInf:function () {
            $.ajax({
                url: "http://localhost:8088/add/stuinf",
                type: 'POST',
                data:JSON.stringify(demo.$data.stu),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        $("#base_cancel").click();
                    }else{
                        alert("err");
                    }
                }
            })
        },
        //添加或修改求职意向
        savejobfor:function () {
            $.ajax({
                url: "http://localhost:8088/addored/jobfor",
                type: 'POST',
                data:JSON.stringify(demo.$data.jobfor),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        $("#jobfor_cancel").click();
                    }else{
                        alert("err");
                    }
                }
            })
        },
        saveschexp:function () {
            $.ajax({
                url: "http://localhost:8088/add/schexp",
                type: 'POST',
                data:JSON.stringify(demo.$data.schexp),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        $("#schexp_cancel").click();
                    }else{
                        alert("err");
                    }
                }
            })
        },
        saveproexp:function () {
            $.ajax({
                url: "http://localhost:8088/add/proexp",
                type: 'POST',
                data:JSON.stringify(demo.$data.proexp),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        $("#proexp_cancel").click();
                    }else{
                        alert("err");
                    }
                }
            })
        },
        saveeduexp:function () {
            $.ajax({
                url: "http://localhost:8088/add/edu",
                type: 'POST',
                data:JSON.stringify(demo.$data.eduexp),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        $("#eduexp_cancel").click();
                    }else{
                        alert("err");
                    }
                }
            })
        },
        saveskill:function () {
            $.ajax({
                url: "http://localhost:8088/add/skill",
                type: 'POST',
                data:JSON.stringify(demo.$data.skill),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        $("#skill_cancel").click();
                    }else{
                        alert("err");
                    }
                }
            })
        },
        saveself:function () {
            $.ajax({
                url: "http://localhost:8088/add/self",
                type: 'POST',
                data:JSON.stringify(demo.$data.self),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        $("#self_cancel").click();
                    }else{
                        alert("err");
                    }
                }
            })
        },
        see:function (res) {
            window.open("preview.html?id="+res.id,"_blank");
        }

    },
    computed: {

    }
})
$(function(){
    //取session
    $.getJSON("http://localhost:8088/gets",
        function (dt) {
            if (dt.status=="ok") {
                demo.$data.user=dt.data;
                getReg();
            }else {
                $("#list").addClass("dn");
                $(".collapsible_menu").append("<dt><a href='login.html' style='color: white'>登录/注册</a></dt>")
            }
        })
    //取简历信息
    function getReg() {
        $.getJSON("http://localhost:8088/get/res",
            {"uid":demo.$data.user.id},
            function (dt) {
                if (dt.status=="ok") {
                    demo.$data.res=dt.data;
                    getRegDetail();
                }
            })
    }
    //取简历细节
    function getRegDetail() {
        var _self=this;
        $.ajax({
            url: "http://localhost:8088/get/res/detail",
            type: 'POST',
            data:JSON.stringify(demo.$data.res),
            contentType:"application/json;charset=utf-8",
            success: function(dt){
                if(dt.status=="ok"){
                    //判断取到的求职意向
                    if (dt.data.jobfor!=null){
                        demo.$data.jobfor=dt.data.jobfor;
                        $("#jobforedit1").removeClass("dn");
                        $("#jobforedit2").removeClass("dn");
                        $("#jobforedit3").addClass("dn");
                        $(".work_detail").removeClass("dn");
                    }else {
                        demo.$data.jobfor.resid=demo.$data.res.id;
                    }
                    //判断取到的个人信息
                    if (dt.data.stuinf!=null){
                        demo.$data.stu=dt.data.stuinf;
                    }else {
                        $("#base1").removeClass("dn");
                        $("#base2").addClass("dn");
                        $("#base3").removeClass("dn");
                        $("#base4").removeClass("dn");
                        demo.$data.stu.uid=demo.$data.user.id;
                    }
                    //判断校园经历
                    if (dt.data.schexp!=null){
                        demo.$data.schexp=dt.data.schexp;
                        $("#exp1").removeClass("dn");
                        $("#exp3").addClass("dn");
                        $(".schexp_detail").removeClass("dn");
                    }else {
                        demo.$data.schexp.resid=demo.$data.res.id;
                    }
                    //判断项目经验
                    if (dt.data.proexp!=null){
                        demo.$data.proexp=dt.data.proexp;
                        $("#proexp1").removeClass("dn");
                        $("#proexp3").addClass("dn");
                        $(".proexp_detail").removeClass("dn");
                    }else {
                        demo.$data.proexp.resid=demo.$data.res.id;
                    }
                    //判断教育经历
                    if (dt.data.eduexp!=null){
                        demo.$data.eduexp=dt.data.eduexp;
                        $("#edu1").removeClass("dn");
                        $("#edu3").addClass("dn");
                        $(".eduexp_detail").removeClass("dn");
                    }else {
                        demo.$data.eduexp.resid=demo.$data.res.id;
                    }
                    //判断专业技能
                    if (dt.data.skill!=null){
                        demo.$data.skill=dt.data.skill;
                        $("#skill1").removeClass("dn");
                        $("#skill3").addClass("dn");
                        $(".skill_detail").removeClass("dn");
                    }else {
                        demo.$data.skill.resid=demo.$data.res.id;
                    }
                    //判断自我评价
                    if (dt.data.self!=null){
                        demo.$data.self=dt.data.self;
                        $("#self1").removeClass("dn");
                        $("#self3").addClass("dn");
                        $(".self_detail").removeClass("dn");
                    }else {
                        demo.$data.self.resid=demo.$data.res.id;
                    }
                }else{
                    alert("err");
                }
            }
        })
    }
    //求职意向控制
    $("#jobforedit1").click(function () {
        $(".work_detail").addClass("dn");
    });
    $("#jobfor_cancel").click(function () {
        if (demo.$data.jobfor!=null){
            $("#jobforedit1").removeClass("dn");
            $("#jobforedit2").removeClass("dn");
            $("#jobforedit3").addClass("dn");
            $(".work_detail").removeClass("dn");
        }
    });
    //个人信息控制
    $("#base_cancel").click(function () {
        if (demo.$data.jobfor!=null){
            $("#base1").removeClass("dn");
            $("#base2").removeClass("dn");
            $("#base3").addClass("dn");
            $("#base4").addClass("dn");
        }
    });
    //校园经历控制
    $("#exp1").click(function () {
        $(this).addClass("dn");
        $("#exp3").addClass("dn");
        $(".schexp_detail").addClass("dn");
        $("#exp2").removeClass("dn");
    });
    $("#schexp_cancel").click(function () {
        $("#exp1").removeClass("dn");
        $("#exp3").addClass("dn");
        $(".schexp_detail").removeClass("dn");
        $("#exp2").addClass("dn");
    });
    //项目经验控制
    $("#proexp1").click(function () {
        $(this).addClass("dn");
        $("#proexp3").addClass("dn");
        $(".proexp_detail").addClass("dn");
        $("#proexp2").removeClass("dn");
    });
    $("#proexp_cancel").click(function () {
        $("#proexp1").removeClass("dn");
        $("#proexp3").addClass("dn");
        $(".proexp_detail").removeClass("dn");
        $("#proexp2").addClass("dn");
    });
    //教育经历控制
    $("#edu1").click(function () {
        $(this).addClass("dn");
        $("#edu3").addClass("dn");
        $(".schexp_detail").addClass("dn");
        $("#edu2").removeClass("dn");
    });
    $("#eduexp_cancel").click(function () {
        $("#edu1").removeClass("dn");
        $("#edu3").addClass("dn");
        $(".schexp_detail").removeClass("dn");
        $("#edu2").addClass("dn");
    });
    //专业技能控制
    $("#skill1").click(function () {
        $(this).addClass("dn");
        $("#skill3").addClass("dn");
        $(".skill_detail").addClass("dn");
        $("#skill2").removeClass("dn");
    });
    $("#skill_cancel").click(function () {
        $("#skill1").removeClass("dn");
        $("#skill3").addClass("dn");
        $(".skill_detail").removeClass("dn");
        $("#skill2").addClass("dn");
    });
    //自我评价控制
    $("#self1").click(function () {
        $(this).addClass("dn");
        $("#self3").addClass("dn");
        $(".self_detail").addClass("dn");
        $("#self2").removeClass("dn");
    });
    $("#self_cancel").click(function () {
        $("#self1").removeClass("dn");
        $("#self3").addClass("dn");
        $(".self_detail").removeClass("dn");
        $("#self2").addClass("dn");
    });
    $("#self3").click(function () {
        $(this).addClass("dn");
        $("#self2").removeClass("dn");
    })
});

