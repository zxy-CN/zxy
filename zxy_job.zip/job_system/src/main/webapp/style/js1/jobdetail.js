var demo=new Vue({
    el:'#jobdetail_vue',
    data:{
        j:{
            company:{
                comname:""
            }
        },
        user:"",
        send:{
            resid:"",
            jobid:""
        }
    },
    methods:{
        sendRes:function () {
            $.getJSON("http://localhost:8088/get/res",
                {"uid":demo.$data.user.id},
                function (dt) {
                    if (dt.status=="ok") {
                        demo.$data.send.resid=dt.data.id;
                        demo.$data.send.jobid=demo.$data.j.id;
                        var r = confirm("您是否确认投递？");
                        if (r == true) {
                            demo.send2();
                        }
                    }else {
                        alert("您没有简历！");
                    }
                })
        },
        send2:function () {
            $.ajax({
                url: "http://localhost:8088/send/res",
                type: 'POST',
                data:JSON.stringify(demo.$data.send),
                contentType:"application/json;charset=utf-8",
                success: function(dt){
                    if(dt.status=="ok"){
                        alert("投递成功")
                    }else{
                        alert("投递失败");
                    }
                }
            })
        }


    },
    computed: {

    }
})
$(function(){
    urlinfo=window.location.href;  //获取当前页面的url
    len=urlinfo.length;//获取url的长度
    offset=urlinfo.indexOf("?");//设置参数字符串开始的位置
    newsidinfo=urlinfo.substr(offset,len)//取出参数字符串
    newsids=newsidinfo.split("=");//对获得的参数字符串按照“=”进行分割
    newsid=decodeURIComponent(newsids[1]);//得到参数值
    //取工作详细
    $.getJSON("http://localhost:8088/get/job",
        {"id":newsid},
        function (dt) {
            if (dt.status=="ok") {
                demo.$data.j=dt.data;
            }else {
            }
        })
        //取session
    $.getJSON("http://localhost:8088/gets",
            function (dt) {
                if (dt.status=="ok") {
                    demo.$data.user=dt.data;
                }else {
                    $("#list").addClass("dn");
                    $(".collapsible_menu").append("<dt><a href='login.html' style='color: white'>登录/注册</a></dt>")
                }
    }),
    $("#fk").mouseenter(function () {
        $("#list dd").css("display","block");
    }),
    $("#fk").mouseleave(function () {
        $("#list dd").css("display","none");
    })
});

